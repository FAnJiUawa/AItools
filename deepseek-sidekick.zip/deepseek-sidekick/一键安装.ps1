﻿# DeepSeek 划词助手 —— 一键安装助手
# 作用：找到你电脑上的 Chrome / Edge，打开扩展管理页，并把插件路径复制到剪贴板。
# 用法：右键本文件 → 使用 PowerShell 运行；或双击 一键安装.bat

$ErrorActionPreference = 'Stop'
$extDir = Split-Path -Parent $MyInvocation.MyCommand.Path

Write-Host ''
Write-Host '==============================================' -ForegroundColor Cyan
Write-Host '   DeepSeek 划词助手 · 安装助手' -ForegroundColor Cyan
Write-Host '==============================================' -ForegroundColor Cyan
Write-Host ''
Write-Host '插件目录：' -NoNewline
Write-Host $extDir -ForegroundColor Yellow
Write-Host ''

if (-not (Test-Path (Join-Path $extDir 'manifest.json'))) {
  Write-Host '× 没找到 manifest.json，请确认本脚本和 manifest.json 在同一个文件夹里。' -ForegroundColor Red
  Read-Host '按回车退出'
  exit 1
}

# 把路径放进剪贴板，稍后粘贴到「选择文件夹」对话框即可
try {
  Set-Clipboard -Value $extDir
  Write-Host '√ 插件路径已复制到剪贴板，等会儿直接 Ctrl+V 粘贴。' -ForegroundColor Green
} catch {
  Write-Host '! 复制到剪贴板失败，请手动复制上面的路径。' -ForegroundColor DarkYellow
}

# 查找浏览器
$candidates = [ordered]@{
  'Chrome' = @(
    "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
    "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
    "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe"
  )
  'Edge' = @(
    "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
    "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe"
  )
}

$found = @()
foreach ($browser in $candidates.Keys) {
  foreach ($p in $candidates[$browser]) {
    if (Test-Path $p) { $found += [pscustomobject]@{ Name = $browser; Path = $p }; break }
  }
}

if ($found.Count -eq 0) {
  Write-Host '! 没有自动找到 Chrome 或 Edge，请手动打开 chrome://extensions 或 edge://extensions。' -ForegroundColor DarkYellow
} else {
  $target = $found[0]
  $url = if ($target.Name -eq 'Chrome') { 'chrome://extensions/' } else { 'edge://extensions/' }
  Write-Host ("√ 找到 {0}：{1}" -f $target.Name, $target.Path) -ForegroundColor Green
  Write-Host ("正在打开 {0} …" -f $url)
  Start-Process -FilePath $target.Path -ArgumentList $url
  if ($found.Count -gt 1) {
    Write-Host ("（同时检测到 {0}，如需安装到另一个浏览器，请手动打开它的扩展管理页）" -f (($found | Select-Object -Skip 1 | ForEach-Object { $_.Name }) -join '、')) -ForegroundColor DarkGray
  }
}

Write-Host ''
Write-Host '接下来只差 3 步：' -ForegroundColor Cyan
Write-Host '  1) 在打开的扩展管理页右上角，打开「开发者模式 / 开发人员模式」开关'
Write-Host '  2) 点击左上角的「加载已解压的扩展程序 / 加载解压缩的扩展」'
Write-Host '  3) 在弹出的文件夹选择框里按 Ctrl+V 粘贴路径，回车确定'
Write-Host ''
Write-Host '装好后打开 https://chat.deepseek.com，选中一段文字就会弹出按钮组。' -ForegroundColor Green
Write-Host ''
Read-Host '按回车关闭本窗口'
