/* 自检脚本（不属于插件本体）：打桩 chrome / location / DOM，验证
 *   「划词追问 → 在当前标签页开新对话 → 自动发送」整条真实流程。
 * 用法： node tools/content-flow.js
 */
'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const ROOT = path.resolve(__dirname, '..');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/* ----------------------------- DOM 打桩 ----------------------------- */

function collect(root, out) {
  out = out || [];
  (root.children || []).forEach((c) => {
    out.push(c);
    if (c.__shadow) collect(c.__shadow, out);
    collect(c, out);
  });
  return out;
}

class El {
  constructor(tag) {
    this.tagName = String(tag || 'div').toUpperCase();
    this.nodeType = 1;
    this.children = [];
    this.parentNode = null;
    this.listeners = {};
    this.style = {};
    this.className = '';
    this.textContent = '';
    this.__value = '';
    this.title = '';
    this.placeholder = '';
    this.isConnected = true;
    this.classList = { add() {}, remove() {}, contains: () => false };
  }
  appendChild(c) {
    if (c.parentNode) c.parentNode.removeChild(c);
    c.parentNode = this;
    this.children.push(c);
    return c;
  }
  removeChild(c) {
    const i = this.children.indexOf(c);
    if (i >= 0) this.children.splice(i, 1);
    c.parentNode = null;
    c.isConnected = false;
    return c;
  }
  remove() {
    if (this.parentNode) this.parentNode.removeChild(this);
    this.isConnected = false;
  }
  setAttribute(k, v) {
    this[k] = v;
    this.attrs = this.attrs || {};
    this.attrs[k] = String(v);
    if (k === 'id' && this.ownerDoc) this.ownerDoc.byId.set(v, this);
  }
  getAttribute(k) {
    return this.attrs ? this.attrs[k] : undefined;
  }
  hasAttribute(k) {
    return !!(this.attrs && Object.prototype.hasOwnProperty.call(this.attrs, k));
  }
  addEventListener(t, fn) {
    (this.listeners[t] = this.listeners[t] || []).push(fn);
  }
  dispatch(t, ev) {
    (this.listeners[t] || [])
      .slice()
      .forEach((fn) => fn(Object.assign({ type: t, target: this, preventDefault() {}, stopPropagation() {} }, ev || {})));
  }
  dispatchEvent(event) {
    this.dispatch(event && event.type, event);
    return true;
  }
  removeEventListener(t, fn) {
    const list = this.listeners[t] || [];
    const i = list.indexOf(fn);
    if (i >= 0) list.splice(i, 1);
  }
  get value() {
    return this.__value || '';
  }
  set value(v) {
    this.__value = String(v);
  }
  focus() {
    if (this.ownerDoc) this.ownerDoc.activeElement = this;
  }
  querySelector(sel) {
    if (sel.charAt(0) === '.') {
      const want = sel.slice(1);
      return collect(this).find((el) => String(el.className || '').split(/\s+/).indexOf(want) >= 0) || null;
    }
    return null;
  }
  querySelectorAll() {
    return [];
  }
  contains(node) {
    return node === this || collect(this).indexOf(node) >= 0;
  }
  getBoundingClientRect() {
    return { left: 0, top: 0, right: 900, bottom: 40, width: 900, height: 40 };
  }
  attachShadow() {
    const s = new El('shadow-root');
    s.isShadow = true;
    s.__host = this;
    this.__shadow = s;
    return s;
  }
}

/* ----------------------------- 每个用例一个干净环境 ----------------------------- */

function makeEnv() {
  const doc = {
    activeElement: null,
    listeners: {},
    byId: new Map(),
    body: new El('body'),
    documentElement: new El('html'),
    textareas: [],
    createElement(tag) {
      const el = new El(tag);
      el.ownerDoc = doc;
      return el;
    },
    getElementById(id) {
      // 真实浏览器按属性查；这里的桩按 id 属性查，并穿透 shadow root
      return collect(doc.documentElement).find((el) => el.id === id) || null;
    },
    querySelector: () => null,
    querySelectorAll(sel) {
      if (sel === 'textarea' || sel === 'textarea[placeholder]') return doc.textareas.slice();
      return [];
    },
    addEventListener(t, fn) {
      (doc.listeners[t] = doc.listeners[t] || []).push(fn);
    },
    removeEventListener() {}
  };
  doc.body.ownerDoc = doc;
  doc.documentElement.ownerDoc = doc;

  const state = { sent: [], prefill: null, navigatedTo: null, openedTab: 0 };

  const chromeStub = {
    runtime: {
      lastError: null,
      onMessage: {
        addListener(fn) {
          state.prefill = fn;
        }
      },
      sendMessage(msg, cb) {
        state.sent.push(msg);
        if (typeof cb === 'function') setTimeout(cb, 5);
      }
    },
    storage: { sync: { get: (d, cb) => cb(d) } }
  };

  const locationStub = {
    pathname: '/',
    search: '',
    href: 'https://chat.deepseek.com/',
    assign(url) {
      state.navigatedTo = url;
    }
  };

  const stubRect = { left: 10, top: 10, width: 120, height: 20, right: 130, bottom: 30 };
  const win = {
    innerWidth: 1280,
    innerHeight: 800,
    getSelection: () => ({
      isCollapsed: false,
      rangeCount: 1,
      toString: () => 'git push',
      getRangeAt: () => ({
        getBoundingClientRect: () => stubRect,
        cloneRange() {
          return this;
        },
        startContainer: null
      })
    }),
    addEventListener() {},
    removeEventListener() {},
    open() {
      state.openedTab++;
      return null;
    }
  };

  const sandbox = {
    console,
    setTimeout,
    clearTimeout,
    setInterval,
    clearInterval,
    requestAnimationFrame: (fn) => setTimeout(fn, 0),
    cancelAnimationFrame: () => {},
    window: win,
    document: doc,
    location: locationStub,
    chrome: chromeStub,
    navigator: { userAgent: 'node-content-flow' },
    URLSearchParams,
    URL,
    Event: class {
      constructor(type, opts) {
        this.type = type;
        Object.assign(this, opts || {});
      }
    },
    KeyboardEvent: class {
      constructor(type, opts) {
        this.type = type;
        Object.assign(this, opts || {});
      }
    },
    HTMLTextAreaElement: class {},
    Map,
    Set,
    Promise,
    Math,
    JSON,
    Date,
    Error,
    String,
    Number,
    Object,
    Array,
    Boolean,
    RegExp,
    isNaN,
    parseInt,
    parseFloat
  };
  sandbox.self = sandbox;
  sandbox.globalThis = sandbox;
  win.document = doc;
  win.location = locationStub;
  win.chrome = chromeStub;

  Object.defineProperty(sandbox.HTMLTextAreaElement.prototype, 'value', {
    configurable: true,
    get() {
      return this.__value || '';
    },
    set(v) {
      this.__value = String(v);
    }
  });

  vm.createContext(sandbox);
  for (const f of ['src/lib/offline-dict.js', 'src/lib/net.js', 'src/lib/ui.js', 'src/content.js']) {
    vm.runInContext(fs.readFileSync(path.join(ROOT, f), 'utf8'), sandbox, { filename: f });
  }
  // 真实浏览器里 self === window，这里补齐，让 content.js 里的 window.* 也能取到
  win.DSKUi = sandbox.DSKUi;
  win.DSKNet = sandbox.DSKNet;
  win.DSKOfflineDict = sandbox.DSKOfflineDict;
  win.HTMLTextAreaElement = sandbox.HTMLTextAreaElement;
  win.Event = sandbox.Event;
  win.KeyboardEvent = sandbox.KeyboardEvent;

  const textarea = () => {
    const el = doc.createElement('textarea');
    el.tagName = 'TEXTAREA';
    el.placeholder = '给 DeepSeek 发送消息';
    doc.body.appendChild(el);
    doc.textareas.push(el);
    return el;
  };

  return {
    doc,
    win,
    sandbox,
    state,
    locationStub,
    stubRect,
    textarea,
    ui: sandbox.DSKUi || win.DSKUi
  };
}

/* ----------------------------- 用例辅助 ----------------------------- */

/** 穿透 shadow root 找到某个 class 的节点 */
function findNode(env, className) {
  return collect(env.doc.body).find((el) => String(el.className || '').split(/\s+/).indexOf(className) >= 0) || null;
}

/** 模拟用户划词后的 pointerup，触发 content.js 的 handleSelection → showToolbar */
function dispatchSelection(env) {
  env.doc.activeElement = null; // 划词时焦点在正文上，不在任何输入框里
  const fns = env.doc.listeners.pointerup || [];
  fns.forEach((fn) => fn({ type: 'pointerup', button: 0, target: env.doc.body, preventDefault() {}, stopPropagation() {} }));
}

/* ----------------------------- 用例 ----------------------------- */

const results = [];
function check(name, cond, extra) {
  results.push({ name, ok: !!cond, extra: extra === undefined ? '' : String(extra) });
}

(async () => {
  /* 用例 1：划词 → 点工具栏「追问」→ 在追问框输入问题 → 点发送。
   * 走的是 content.js 注册在工具栏上的真实回调，以及真实的 ui.js 面板。 */
  {
    const env = makeEnv();
    env.textarea();
    dispatchSelection(env); // 模拟划词后 pointerup，触发 content.js 的 handleSelection
    await sleep(60); // handleSelection 内部有 10ms 延迟
    const toolbar = env.ui.getToolbar();
    check('划词后工具栏已显示', !!toolbar);
    check('加载后向后台报了到', env.state.sent.some((m) => m.type === 'DSK_TAB_READY'));

    // 点工具栏第一个按钮「追问」→ content.js 的 openAskPanel
    toolbar.children[0].listeners.click[0]();
    const box = findNode(env, 'dsk-input');
    check('追问框里有输入区', !!box, box ? box.tagName : 'null');
    box.value = '解释这段话：';
    const sendBtn = findNode(env, 'dsk-send');
    check('追问面板里有发送按钮', !!sendBtn, sendBtn ? sendBtn.className : 'null');
    check('发送前的输入内容正确', box.value === '解释这段话：', box.value);

    sendBtn.listeners.click[0]();
    await sleep(120);
    check('没有另开新标签页', env.state.openedTab === 0, 'opened=' + env.state.openedTab);

    await sleep(320);
    const target = String(env.state.navigatedTo || '');
    check('已在当前标签页导航到新对话', !!target, target);
    check('新对话地址 = chat.deepseek.com 根路径', target.indexOf('https://chat.deepseek.com/?q=') === 0, target.slice(0, 70));
    check(
      '地址里同时含问题与原文引用',
      decodeURIComponent(target).indexOf('解释这段话：') > 0 && decodeURIComponent(target).indexOf('> git push') > 0,
      decodeURIComponent(target).slice(0, 90)
    );
  }

  /* 用例 2：DeepSeek 自己已经把 ?q= 发出去（路由变成会话页）→ 不要再插一遍 */
  {
    const env = makeEnv();
    const inputEl = env.textarea();
    inputEl.value = 'BLANK';
    env.locationStub.pathname = '/a/chat/s/abc123';
    env.state.prefill({ type: 'DSK_PREFILL', text: '解释这段话：\n\n> git push' });
    await sleep(700);
    check('路由已变化时不再补发', inputEl.value === 'BLANK', inputEl.value);
  }

  /* 用例 3：页面没自己发出去（输入框为空）→ 自动填入并回车 */
  {
    const env = makeEnv();
    const inputEl = env.textarea();
    const keys = [];
    inputEl.addEventListener('keydown', (e) => keys.push(e.key));
    env.state.prefill({ type: 'DSK_PREFILL', text: '解释这段话：\n\n> git push' });
    await sleep(900);
    check('已自动填入追问内容', inputEl.value.indexOf('解释这段话') === 0, JSON.stringify(inputEl.value.slice(0, 24)));
    check('已自动按下回车', keys.indexOf('Enter') >= 0, '事件=' + JSON.stringify(keys) + ' value=' + JSON.stringify(inputEl.value.slice(0, 10)));
  }

  /* 用例 4：输入框里已有用户在打字 → 不要抢 */
  {
    const env = makeEnv();
    const inputEl = env.textarea();
    inputEl.value = '我自己正在写的内容';
    const keys = [];
    inputEl.addEventListener('keydown', (e) => keys.push(e.key));
    env.state.prefill({ type: 'DSK_PREFILL', text: '解释这段话：\n\n> git push' });
    await sleep(900);
    check('不覆盖用户已输入的内容', inputEl.value === '我自己正在写的内容', inputEl.value);
    check('也不替用户按回车', keys.length === 0, keys.join(','));
  }

  let failed = 0;
  for (const r of results) {
    if (!r.ok) failed++;
    console.log((r.ok ? '  ✓ ' : '  ✗ ') + r.name + (r.ok ? '' : '   → ' + r.extra));
  }
  console.log('\n' + (results.length - failed) + '/' + results.length + ' 项通过');
  process.exit(failed ? 1 : 0);
})();
