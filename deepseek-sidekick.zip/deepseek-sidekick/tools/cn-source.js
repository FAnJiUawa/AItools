/* 自检脚本（不属于插件本体）：用桩好的 fetch 验证「国内可直连翻译源」的解析逻辑与回退顺序，
 * 顺便校验自己实现的 MD5（百度官方接口签名要用）是否正确。
 * 用法： node tools/cn-source.js
 */
'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const crypto = require('crypto');

const ROOT = path.resolve(__dirname, '..');

const results = [];
function check(name, cond, extra) {
  results.push({ name: name, ok: !!cond, extra: extra === undefined ? '' : String(extra) });
}

/* ---------------------------- 桩数据 ---------------------------- */

const BAIDU_SUG = {
  errno: 0,
  data: [
    { k: 'translation', v: 'n. 翻译；译文；转化' },
    { k: 'translation', v: '翻译' }
  ]
};
const BAIDU_TRANS = { data: [{ dst: '早上好', src: 'Good morning' }] };
const YOUDAO = {
  ec: {
    usphone: 'trænsˈleɪʃn',
    trs: [{ tr: [{ l: { i: ['n. 翻译；译文'] } }] }]
  }
};
const BAIDU_OFFICIAL = { from: 'en', to: 'zh', trans_result: [{ src: 'translation', dst: '翻译；译文' }] };

const calls = [];
let breakFreeSources = false; // 置 true 时，免密钥公开接口一律失败，用来验证「用户密钥一定会被使用」

function makeRes(body, status) {
  const text = typeof body === 'string' ? body : JSON.stringify(body);
  const code = status || 200;
  return {
    ok: code >= 200 && code < 300,
    status: code,
    text: async () => text,
    json: async () => JSON.parse(text)
  };
}

/* ---------------------------- 沙箱 ---------------------------- */

const sandbox = {
  console: console,
  setTimeout: setTimeout,
  clearTimeout: clearTimeout,
  URL: URL,
  encodeURIComponent: encodeURIComponent,
  AbortController: AbortController,
  Math: Math,
  JSON: JSON,
  Map: Map,
  Set: Set,
  Array: Array,
  Object: Object,
  String: String,
  Number: Number,
  Boolean: Boolean,
  Promise: Promise,
  RegExp: RegExp,
  Date: Date,
  Error: Error,
  TypeError: TypeError,
  isNaN: isNaN,
  parseInt: parseInt,
  parseFloat: parseFloat,
  fetch: async (url, init) => {
    calls.push({ url: url, init: init });
    if (breakFreeSources && (url.indexOf('fanyi.baidu.com') >= 0 || url.indexOf('dict.youdao.com') >= 0)) {
      throw new TypeError('Failed to fetch');
    }
    if (url.indexOf('fanyi.baidu.com/sug') >= 0) return makeRes(BAIDU_SUG, 200);
    if (url.indexOf('fanyi.baidu.com/transapi') >= 0) return makeRes(BAIDU_TRANS, 200);
    if (url.indexOf('dict.youdao.com/jsonapi') >= 0) return makeRes(YOUDAO, 200);
    if (url.indexOf('fanyi-api.baidu.com') >= 0) return makeRes(BAIDU_OFFICIAL, 200);
    if (url.indexOf('api.dictionaryapi.dev') >= 0) return makeRes({}, 404);
    if (url.indexOf('translate.google.com') >= 0) {
      return makeRes(JSON.stringify([[['翻译', 'translation', null, null, 10]], null, 'en']), 200);
    }
    if (url.indexOf('mymemory') >= 0) {
      return makeRes({ responseData: { translatedText: '翻译' } }, 200);
    }
    if (url.indexOf('custom.example.com') >= 0) {
      return makeRes({ choices: [{ message: { content: '{"phonetic":"/k/","meaning":"自定义"}' } }] }, 200);
    }
    throw new Error('unexpected url ' + url);
  }
};
sandbox.self = sandbox;
sandbox.globalThis = sandbox;

vm.createContext(sandbox);
['src/lib/offline-dict.js', 'src/lib/cn-dict.js', 'src/lib/translate.js'].forEach((f) => {
  vm.runInContext(fs.readFileSync(path.join(ROOT, f), 'utf8'), sandbox, { filename: f });
});

const cn = sandbox.DSKCnDict;
const T = sandbox.DSKTranslate;

/* ---------------------------- 用例 ---------------------------- */

(async () => {
  /* 1. MD5 正确性（百度官方接口签名靠它） */
  check('MD5 空串正确', cn.md5('') === 'd41d8cd98f00b204e9800998ecf8427e', cn.md5(''));
  check('MD5 abc 正确', cn.md5('abc') === '900150983cd24fb0d6963f7d28e17f72', cn.md5('abc'));
  check(
    'MD5 与 Node 实现一致（含中文）',
    cn.md5('翻译test 123') === crypto.createHash('md5').update('翻译test 123', 'utf8').digest('hex'),
    cn.md5('翻译test 123')
  );

  /* 2. 百度词典解析 */
  const b = await cn._internal.viaBaiduSuggest('translation', 5000);
  check('百度词典能解析出中文释义', !!(b && /翻译/.test(b.meaning)), b && b.meaning);
  check(
    '百度词典走的是 POST',
    calls.some((c) => c.url.indexOf('fanyi.baidu.com/sug') >= 0 && c.init && c.init.method === 'POST')
  );

  /* 3. 有道词典解析（带音标） */
  const y = await cn._internal.viaYoudaoDict('translation', 5000);
  check('有道词典能解析出音标', !!(y && y.phonetic), y && y.phonetic);
  check('有道词典能解析出释义', !!(y && /翻译/.test(y.meaning)), y && y.meaning);

  /* 4. 百度整句翻译解析 */
  const t = await cn._internal.viaBaiduTransapi('Good morning', 5000);
  check('百度整句翻译能解析', !!(t && t.meaning === '早上好'), t && t.meaning);

  /* 5. 百度官方接口（需 appid + 密钥） */
  const opts = { baidu: { appid: '123', key: 'secret' } };
  const off = await cn._internal.viaBaiduOfficial('translation', 5000, opts);
  check('百度官方接口能解析', !!(off && /翻译/.test(off.meaning)), off && off.meaning);
  const officialCall = calls.slice().reverse().find((c) => c.url.indexOf('fanyi-api.baidu.com') >= 0);
  check(
    '官方接口带上了 sign 参数',
    !!(officialCall && officialCall.url.indexOf('&sign=') > 0),
    officialCall && officialCall.url.slice(0, 80)
  );

  /* 6. 整体链路：单词能拿到中文释义 */
  const word = await T.translateText('translation', { options: { provider: 'auto' } });
  check('单词能拿到中文释义', !!(word.meaning && /翻译/.test(word.meaning)), word.meaning);
  check('结果里标注了来源', !!word.provider, word.provider);

  /* 7. 离线模式不受影响 */
  calls.length = 0;
  const offMode = await T.translateText('phase', { options: { provider: 'offline' } });
  check('离线模式仍然可用', !!(offMode.meaning && offMode.phonetic), offMode.meaning);
  check('离线模式零网络请求', calls.length === 0, 'calls=' + calls.length);

  /* 7b. 关键回归：来源选「只用免费在线词典」+ 免密钥公开接口全挂时，
   *     用户自己填的百度密钥必须仍然被使用（否则等于白申请） */
  {
    breakFreeSources = true;
    calls.length = 0;
    const freeOpts = { provider: 'free', baidu: { appid: '123', key: 'secret' } };
    const r = await T.translateText('translation7b', { options: freeOpts });
    const usedOfficial = calls.some((c) => c.url.indexOf('fanyi-api.baidu.com') >= 0);
    check('prov=free 时仍然用了百度官方密钥', usedOfficial, '官方接口调用=' + usedOfficial);
    check('prov=free 时能出结果', !!(r.meaning && /翻译/.test(r.meaning)), r.meaning);
    breakFreeSources = false;
  }

  /* 7c. 来源选「只用自定义接口」但没配自定义 → 也应兜底到百度密钥 */
  {
    breakFreeSources = true;
    calls.length = 0;
    const customOpts = { provider: 'custom', custom: {}, baidu: { appid: '123', key: 'secret' } };
    const r = await T.translateText('translation7c', { options: customOpts });
    const usedOfficial = calls.some((c) => c.url.indexOf('fanyi-api.baidu.com') >= 0);
    check('prov=custom 没配自定义时兜底到百度', usedOfficial, '官方接口调用=' + usedOfficial);
    check('prov=custom 兜底后能出结果', !!(r.meaning && /翻译/.test(r.meaning)), r.meaning);
    breakFreeSources = false;
  }

  /* 8. 诊断：列出每个源的状态 */
  const rows = await T.probeSources({ baidu: { appid: '123', key: 'secret' } }, 5000);
  const byId = {};
  rows.forEach((r) => {
    byId[r.id] = r;
  });
  check('诊断列出了所有源', rows.length >= 7, '数量=' + rows.length);
  check('诊断认为百度可用', !!(byId.baidu && byId.baidu.status === 'ok'), byId.baidu && byId.baidu.status);
  check('诊断认为有道可用', !!(byId.youdao && byId.youdao.status === 'ok'), byId.youdao && byId.youdao.status);
  check('诊断标出了离线词库可用', !!(byId.offline && byId.offline.status === 'ok'), byId.offline && byId.offline.status);
  check('诊断输出含耗时', rows.every((r) => typeof r.ms === 'number'), JSON.stringify(rows[rows.length - 1]));

  /* 9. 诊断要能带出「原始返回」，否则用户没法反馈问题 */
  {
    const realFetch = sandbox.fetch;
    sandbox.fetch = async (url, init) => {
      if (url.indexOf('fanyi-api.baidu.com') >= 0) {
        // 模拟「额度扣了、但返回不是我们预期的结构」
        return makeRes({ from: 'en', to: 'zh', weird_field: '译文藏在这里' }, 200);
      }
      return realFetch(url, init);
    };
    const rows2 = await T.probeSources({ baidu: { appid: '123', key: 'secret' } }, 5000);
    const official = rows2.find((r) => r.id === 'baidu-official');
    check('结构不符时状态为 error', !!(official && official.status === 'error'), official && official.status);
    check(
      '错误里点明了缺 trans_result',
      !!(official && /trans_result/.test(official.detail || '')),
      official && official.detail
    );
    check(
      '诊断带出了原始返回',
      !!(official && official.raw && /weird_field/.test(official.raw)),
      official && String(official.raw).slice(0, 60)
    );
    sandbox.fetch = realFetch;
  }

  /* 10. 百度返回错误码时，提示要能说人话（而不是抛 xxx is not defined） */
  {
    const realFetch = sandbox.fetch;
    sandbox.fetch = async (url, init) => {
      if (url.indexOf('fanyi-api.baidu.com') >= 0) {
        return makeRes({ error_code: '54001', error_msg: 'Invalid Sign' }, 200);
      }
      return realFetch(url, init);
    };
    const rows3 = await T.probeSources({ baidu: { appid: '123', key: 'bad' } }, 5000);
    const official = rows3.find((r) => r.id === 'baidu-official');
    check('错误码被识别', !!(official && /54001/.test(official.detail || '')), official && official.detail);
    check('错误码被翻译成人话', !!(official && /签名错误/.test(official.detail || '')), official && official.detail);
    check('没有出现 not defined', !!(official && !/not defined/.test(official.detail || '')), official && official.detail);
    sandbox.fetch = realFetch;
  }

  /* 11. 百度公开接口失败时，原始返回要能被诊断页看到（用户截图里那种 errno:1022） */
  {
    const realFetch = sandbox.fetch;
    // 让 cnLookup 一路走到 transapi：前两个源返回空（不算错误），transapi 返回 1022 错误
    sandbox.fetch = async (url, init) => {
      if (url.indexOf('fanyi.baidu.com/transapi') >= 0) {
        return makeRes({ errno: 1022, errmsg: '\u8bf7\u6c42\u53c2\u6570\u9519\u8bef', error: 1022 }, 200);
      }
      if (url.indexOf('fanyi.baidu.com/sug') >= 0) {
        return makeRes({ errno: 0, data: [] }, 200); // 空结果，不抛错
      }
      if (url.indexOf('dict.youdao.com') >= 0) {
        return makeRes({}, 200); // 同样空结果
      }
      return realFetch(url, init);
    };
    const rows4 = await T.probeSources({}, 5000);
    const trans = rows4.find((r) => r.id === 'baidu');
    check(
      '公开接口失败时诊断给出原始返回',
      !!(trans && String(trans.raw || '').length > 0),
      trans && JSON.stringify({ status: trans.status, detail: trans.detail, raw: String(trans.raw || '').slice(0, 80) })
    );

    // 直接调用时，错误信息本身也要能说清楚
    const direct = await cn._internal
      .viaBaiduTransapi('hello', 5000)
      .then(() => 'no-error')
      .catch((e) => e.message);
    check('errno 会抛成可读错误', /1022/.test(direct) && /参数错误或账户不可用/.test(direct), direct);
    sandbox.fetch = realFetch;
  }

  /* 12. 顺序：有道最全排第一；填了密钥时百度官方要排在免密钥接口之前 */
  {
    const order = [];
    const realFetch = sandbox.fetch;
    sandbox.fetch = async (url, init) => {
      let tag = 'other';
      if (url.indexOf('fanyi-api.baidu.com') >= 0) tag = 'official';
      else if (url.indexOf('fanyi.baidu.com/sug') >= 0) tag = 'sug';
      else if (url.indexOf('dict.youdao.com') >= 0) tag = 'youdao';
      if (tag !== 'other') order.push(tag);
      // 让前两个源都返回"空结果"，把整条链走完，才能看出优先级
      if (tag === 'youdao') return makeRes({}, 200);
      if (tag === 'official') return makeRes({ from: 'en', to: 'zh', trans_result: [] }, 200);
      return realFetch(url, init);
    };
    const r = await cn.cnLookup('translation', 5000, { baidu: { appid: '1', key: 'k' } });
    check('有道排第一（实测最全）', order[0] === 'youdao', order.join(' → '));
    check('填了密钥时官方接口排在免密钥接口之前', order.indexOf('official') < order.indexOf('sug'), order.join(' → '));
    check('链路走完后仍有结果', !!(r && r.meaning), r && r.provider);
    sandbox.fetch = realFetch;
  }

  /* 13. 没填密钥时，不应去调用官方接口（免得白报错） */
  {
    const order = [];
    const realFetch = sandbox.fetch;
    sandbox.fetch = async (url, init) => {
      if (url.indexOf('fanyi-api.baidu.com') >= 0) order.push('official');
      else if (url.indexOf('dict.youdao.com') >= 0) order.push('youdao');
      return realFetch(url, init);
    };
    await cn.cnLookup('translation', 5000, { baidu: {} });
    check('没填密钥就不碰官方接口', order.indexOf('official') < 0, order.join(' → '));
    sandbox.fetch = realFetch;
  }

  let failed = 0;
  for (const r of results) {
    if (!r.ok) failed++;
    console.log((r.ok ? '  OK   ' : '  FAIL ') + r.name + (r.ok ? '' : '   -> ' + r.extra));
  }
  console.log('\n' + (results.length - failed) + '/' + results.length + ' 项通过');
  process.exit(failed ? 1 : 0);
})();
