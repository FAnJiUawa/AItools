/* 自检脚本（不属于插件本体）：用桩好的 fetch 验证「国内可直连翻译源」的解析逻辑与回退顺序，
 * 顺便校验自己实现的 MD5（百度官方接口签名要用）是否正确。
 * 用法： node tools/cn-source.js
 */
'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const crypto = require('crypto');

const ROOT = path.resolve(__dirname, '..');

const results = [];
function check(name, cond, extra) {
  results.push({ name, ok: !!cond, extra: extra === undefined ? '' : String(extra) });
}

/* ---------------------------- 桩数据 ---------------------------- */

const BAIDU_SUG = {
  errno: 0,
  data: [
    { k: 'translation', v: 'n. 翻译；译文；转化' },
    { k: 'translation', v: '翻译' }
  ]
};
const BAIDU_SUG_EMPTY = { errno: 0, data: [] };
const BAIDU_TRANS = { data: [{ dst: '早上好', src: 'Good morning' }] };
const YOUDao = {
  ec: {
    usphone: 'trænsˈleɪʃn',
    trs: [{ tr: [{ l: { i: ['n. 翻译；译文'] } }] }]
  }
};
const BAIDU_OFFICIAL = { from: 'en', to: 'zh', trans_result: [{ src: 'translation', dst: '翻译；译文' }] };
const BAIDU_LLM = {
  result: { trans_content: '大模型给的译文' },
  error_code: '0'
};

const calls = [];

function makeRes(body, status, asText) {
  const text = asText || typeof body === 'string' ? body : JSON.stringify(body);
  return {
    ok: (status || 200) >= 200 && (status || 200) < 300,
    status: status || 200,
    text: async () => text,
    json: async () => (typeof body === 'string' ? JSON.parse(body) : body)
  };
}

/* ---------------------------- 沙箱 ---------------------------- */

const sandbox = {
  console,
  setTimeout,
  clearTimeout,
  URL,
  encodeURIComponent,
  AbortController,
  JSON,
  Map,
  Set,
  Array,
  Object,
  String,
  Number,
  Boolean,
  Math,
  Promise,
  RegExp,
  Date,
  Error,
  TypeError,
  isNaN,
  parseInt,
  parseFloat,
  crypto: undefined, // 插件里没用到 WebCrypto，这里显式留空
  fetch: async (url, init) => {
    calls.push({ url, init });
    if (url.indexOf('fanyi.baidu.com/sug') >= 0) {
      return makeRes(BAIDU_SUG, 200);
    }
    if (url.indexOf('fanyi.baidu.com/transapi') >= 0) {
      return makeRes(BAIDU_TRANS, 200);
    }
    if (url.indexOf('dict.youdao.com/jsonapi') >= 0) {
      return makeRes(YOUDao, 200);
    }
    if (url.indexOf('fanyi-api.baidu.com') >= 0) {
      if (url.indexOf('aiTextTranslate') >= 0) return makeRes(BAIDU_LLM, 200);
      return makeRes(BAIDU_OFFICIAL, 200);
    }
    if (url.indexOf('api.dictionaryapi.dev') >= 0) {
      return makeRes({}, 404);
    }
    if (url.indexOf('translate.google.com') >= 0) {
      return makeRes(JSON.stringify([[['翻译', 'translation', null, null, 10]], null, 'en']), 200);
    }
    if (url.indexOf('mymemory') >= 0) {
      return makeRes({ responseData: { translatedText: '翻译' } }, 200);
    }
    if (url.indexOf('custom.example.com') >= 0) {
      return makeRes({ choices: [{ message: { content: '{"phonetic":"/k/","meaning":"自定义"}' } }] }, 200);
    }
    throw new Error('unexpected url ' + url);
  }
};
sandbox.self = sandbox;
sandbox.globalThis = sandbox;

vm.createContext(sandbox);
for (const f of ['src/lib/offline-dict.js', 'src/lib/cn-dict.js', 'src/lib/translate.js']) {
  vm.runInContext(fs.readFileSync(path.join(ROOT, f), 'utf8'), sandbox, { filename: f });
}

const cn = sandbox.DSKCnDict;
const T = sandbox.DSKTranslate;

/* ---------------------------- 用例 ---------------------------- */

(async () => {
  /* 1. MD5 正确性（百度官方接口签名靠它） */
  check('MD5("") 正确', cn.md5('') === 'd41d8cd98f00b204e9800998ecf8427e', cn.md5(''));
  check('MD5("abc") 正确', cn.md5('abc') === '900150983cd24fb0d6963f7d28e17f72', cn.md5('abc'));
  check(
    'MD5 与 Node 实现一致（含中文）',
    cn.md5('翻译test 123') === crypto.createHash('md5').update('翻译test 123', 'utf8').digest('hex'),
    cn.md5('翻译test 123')
  );

  /* 2. 百度词典解析 */
  const b = await cn._internal.viaBaiduSuggest('translation', 5000);
  check('百度词典能解析出中文释义', !!(b && /翻译/.test(b.meaning)), b && b.meaning);
  check('百度词典走的是 POST', calls.some((c) => c.url.indexOf('fanyi.baidu.com/sug') >= 0 && c.init && c.init.method === 'POST'));

  /* 3. 有道词典解析（带音标） */
  const y = await cn._internal.viaYoudaoDict('translation', 5000);
  check('有道词典能解析出音标', !!(y && y.phonetic), y && y.phonetic);
  check('有道词典能解析出释义', !!(y && /翻译/.test(y.meaning)), y && y.meaning);

  /* 4. 百度整句翻译解析 */
  const t = await cn._internal.viaBaiduTransapi('Good morning', 5000);
  check('百度整句翻译能解析', !!(t && t.meaning === '早上好'), t && t.meaning);

  /* 5. 百度官方接口（需 appid + 密钥） */
  const opts = { baidu: { appid: '123', key: 'secret' } };
  const off = await cn._internal.viaBaiduOfficial('translation', 5000, opts);
  check('百度官方接口能解析', !!(off && /翻译/.test(off.meaning)), off && off.meaning);
  const officialCall = calls.reverse().find((c) => c.url.indexOf('fanyi-api.baidu.com') >= 0);
  check('官方接口带上了 sign 参数', !!(officialCall && officialCall.url.indexOf('&sign=') > 0), officialCall && officialCall.url.slice(0, 80));

  /* 5b. 百度大模型文本翻译（只需一个 API Key） */
  const llmOpts = { baidu: { llmKey: 'llm-key-123' } };
  const llm = await cn._internal.viaBaiduLlm('translation', 5000, llmOpts);
  check('大模型翻译能解析出译文', !!(llm && /大模型给的译文/.test(llm.meaning)), llm && llm.meaning);
  check('hasBaiduLlmKey 能识别 Key', cn.hasBaiduLlmKey(llmOpts) === true);
  check('没填 Key 时不认为可用', cn.hasBaiduLlmKey({ baidu: {} }) === false);
  const llmCall = calls.reverse().find((c) => c.url.indexOf('aiTextTranslate') >= 0);
  check('大模型接口带上了 Bearer Key', !!(llmCall && llmCall.init && /Bearer llm-key-123/.test(JSON.stringify(llmCall.init.headers))), llmCall && JSON.stringify(llmCall.init.headers));

  /* 5c. 只填大模型 Key 时，cnLookup 应优先用它（而不是免密钥公开接口） */
  calls.length = 0;
  const prefer = await cn.cnLookup('translation', 5000, llmOpts);
  check('填了大模型 Key 就走大模型', !!(prefer && prefer.provider === 'baidu-llm'), prefer && prefer.provider);
  check('不会再请求公开接口', !calls.some((c) => c.url.indexOf('fanyi.baidu.com/sug') >= 0), calls.map((c) => c.url.split('/')[2]).join(','));

  /* 5d. 勾了「不用公开接口」且没填密钥 → 直接放弃，不白白发请求 */
  calls.length = 0;
  const none = await cn.cnLookup('translation', 5000, { disableNative: true, baidu: {} });
  check('禁用公开接口且无密钥时返回空', none === null, JSON.stringify(none));
  check('也没有发任何请求', calls.length === 0, 'calls=' + calls.length);

  /* 6. 整体链路：词典优先，中文源能兜底 */
  const word = await T.translateText('translation', { options: { provider: 'auto' } });
  check('单词能拿到中文释义', !!(word.meaning && /翻译/.test(word.meaning)), word.meaning);
  check('结果里标注了来源', !!word.provider, word.provider);

  /* 7. 离线模式不受影响 */
  calls.length = 0;
  const offMode = await T.translateText('phase', { options: { provider: 'offline' } });
  check('离线模式仍然可用', !!(offMode.meaning && offMode.phonetic), offMode.meaning);
  check('离线模式零网络请求', calls.length === 0, 'calls=' + calls.length);

  /* 8. 诊断：应把每个源的状态都列出来，并且有源可用 */
  const rows = await T.probeSources({ baidu: { appid: '123', key: 'secret', llmKey: 'llm-key-123' } }, 5000);
  const byId = {};
  rows.forEach((r) => (byId[r.id] = r));
  check('诊断列出了所有源', rows.length >= 6, '数量=' + rows.length);
  check('诊断认为百度可用', byId.baidu && byId.baidu.status === 'ok', byId.baidu && byId.baidu.status);
  check('诊断标出了填过的密钥', !!(byId.baidu && byId.baidu.tags && byId.baidu.tags.join()).match(/大模型 Key/), byId.baidu && JSON.stringify(byId.baidu.tags));
  check('诊断认为有道可用', byId.youdao && byId.youdao.status === 'ok', byId.youdao && byId.youdao.status);
  check('诊断标出了离线词库可用', byId.offline && byId.offline.status === 'ok', byId.offline && byId.offline.status);
  check(
    'diagnose 输出含耗时',
    rows.every((r) => typeof r.ms === 'number'),
    JSON.stringify(rows[rows.length - 1])
  );

  let failed = 0;
  for (const r of results) {
    if (!r.ok) failed++;
    console.log((r.ok ? '  ✓ ' : '  ✗ ') + r.name + (r.ok ? '' : '   → ' + r.extra));
  }
  console.log('\n' + (results.length - failed) + '/' + results.length + ' 项通过');
  process.exit(failed ? 1 : 0);
})();
