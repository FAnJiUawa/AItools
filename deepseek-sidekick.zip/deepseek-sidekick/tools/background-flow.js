/* 自检脚本（不属于插件本体）：在 Node 里桩掉 Service Worker / chrome API 与 fetch，
 * 把真实的 background.js + translate.js 跑起来，验证「页面发来的翻译请求能被正确应答」。
 * 这样能在不打开浏览器的前提下复现/预防 "translateText is not defined" 这类打包问题。
 * 用法： node tools/background-flow.js
 */
'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const ROOT = path.resolve(__dirname, '..');

const results = [];
function check(name, cond, extra) {
  results.push({ name, ok: !!cond, extra: extra === undefined ? '' : String(extra) });
}

/* ------------------------------ 桩 ------------------------------ */

const listeners = {
  onMessage: [],
  onInstalled: [],
  onUpdated: [],
  onRemoved: []
};

const fetches = [];
function makeResponse(body, status) {
  return {
    ok: status >= 200 && status < 300,
    status,
    text: async () => (typeof body === 'string' ? body : JSON.stringify(body)),
    json: async () => (typeof body === 'string' ? JSON.parse(body) : body)
  };
}

const DICT_JSON = [
  {
    word: 'include',
    phonetic: '/ɪnˈkluːd/',
    phonetics: [{ text: '/ɪnˈkluːd/', audio: '//ssl.gstatic.com/dictionary/static/sounds/include.mp3' }],
    meanings: [
      {
        partOfSpeech: 'verb',
        definitions: [
          { definition: 'comprise or contain as part of a whole.', example: 'the price includes dinner' }
        ]
      }
    ]
  }
];

const sandbox = {
  console,
  setTimeout,
  clearTimeout,
  URL,
  encodeURIComponent,
  AbortController,
  JSON,
  Map,
  Set,
  Array,
  Object,
  String,
  Number,
  Boolean,
  Math,
  Promise,
  RegExp,
  Date,
  Error,
  TypeError,
  isNaN,
  parseInt,
  parseFloat,
  // 模拟 MV3 worker 里的 importScripts：把 worker 侧脚本读进同一个作用域
  importScripts(...files) {
    for (const f of files) {
      const full = path.join(ROOT, 'src', f);
      if (!fs.existsSync(full)) throw new Error('importScripts 找不到文件: ' + f);
      vm.runInContext(fs.readFileSync(full, 'utf8'), sandbox, { filename: 'src/' + f });
    }
  },
  self: null,
  fetch: async (url, init) => {
    fetches.push(url);
    void init;
    if (url.indexOf('api.dictionaryapi.dev') >= 0) {
      return url.indexOf('include') >= 0 ? makeResponse(DICT_JSON, 200) : makeResponse({}, 404);
    }
    if (url.indexOf('translate.google.com') >= 0) {
      return makeResponse(JSON.stringify([[['包含', 'include', null, null, 10]], null, 'en']), 200);
    }
    if (url.indexOf('mymemory') >= 0) {
      return makeResponse({ responseData: { translatedText: '包含' } }, 200);
    }
    if (url.indexOf('custom.example.com') >= 0) {
      return makeResponse(
        { choices: [{ message: { content: '{"phonetic":"/kʌstəm/","meaning":"自定义接口返回的释义"}' } }] },
        200
      );
    }
    if (url.indexOf('fanyi.baidu.com/sug') >= 0) {
      return makeResponse({ errno: 0, data: [{ k: 'translation', v: 'n. 翻译；译文；转化' }] }, 200);
    }
    throw new Error('unexpected url ' + url);
  }
};
sandbox.self = sandbox;
sandbox.globalThis = sandbox;
sandbox.self.addEventListener = (type, fn) => {
  if (listeners[type]) listeners[type].push(fn);
};

const storedOptions = { options: null };
const LOG_STORE = {}; // 模拟 chrome.storage.session

function makeArea() {
  return {
    get(defaults, cb) {
      const out = {};
      Object.keys(defaults || {}).forEach((k) => {
        out[k] = k in LOG_STORE ? LOG_STORE[k] : defaults[k];
      });
      if (typeof cb === 'function') cb(out);
      return Promise.resolve(out);
    },
    set(obj, cb) {
      Object.assign(LOG_STORE, obj);
      if (typeof cb === 'function') cb();
      return Promise.resolve();
    },
    remove(key, cb) {
      delete LOG_STORE[key];
      if (typeof cb === 'function') cb();
      return Promise.resolve();
    }
  };
}

const chromeStub = {
  runtime: {
    onInstalled: { addListener: (fn) => listeners.onInstalled.push(fn) },
    onMessage: { addListener: (fn) => listeners.onMessage.push(fn) }
  },
  tabs: {
    onUpdated: { addListener: (fn) => listeners.onUpdated.push(fn) },
    onRemoved: { addListener: (fn) => listeners.onRemoved.push(fn) },
    sendMessage: () => Promise.resolve()
  },
  storage: {
    session: makeArea(),
    local: makeArea(),
    sync: {
      get(defaults, cb) {
        cb({ options: storedOptions.options || defaults.options });
      },
      set(obj) {
        storedOptions.options = obj.options;
      }
    }
  }
};
sandbox.chrome = chromeStub;
sandbox.setInterval = setInterval;
sandbox.clearInterval = clearInterval;

/* ------------------------------ 加载后台 ------------------------------ */

const bgPath = path.join(ROOT, 'src/background.js');
vm.createContext(sandbox);
try {
  vm.runInContext(fs.readFileSync(bgPath, 'utf8'), sandbox, { filename: 'src/background.js' });
  check('background.js 能正常加载（含 importScripts）', true);
} catch (err) {
  check('background.js 能正常加载（含 importScripts）', false, err.message);
}

/**
 * 模拟 Service Worker 被回收后重启：新建一个干净的作用域，
 * 但 LOG_STORE（session 存储）与 storedOptions 共享，和真实情况一致。
 * 构造顺序与主沙箱保持一致（先建对象、后 createContext）。
 */
function reloadBackground() {
  const myListeners = { onMessage: [], onInstalled: [], onUpdated: [], onRemoved: [] };
  const revived = {
    console: console,
    setTimeout: setTimeout,
    clearTimeout: clearTimeout,
    setInterval: setInterval,
    clearInterval: clearInterval,
    URL: URL,
    encodeURIComponent: encodeURIComponent,
    AbortController: AbortController,
    Math: Math,
    JSON: JSON,
    Map: Map,
    Set: Set,
    Array: Array,
    Object: Object,
    String: String,
    Number: Number,
    Boolean: Boolean,
    Promise: Promise,
    RegExp: RegExp,
    Date: Date,
    Error: Error,
    TypeError: TypeError,
    WeakMap: WeakMap,
    isNaN: isNaN,
    parseInt: parseInt,
    parseFloat: parseFloat,
    fetch: sandbox.fetch,
    // 模拟 MV3 worker 的 importScripts：与主沙箱同一份实现
    importScripts: function (...files) {
      for (const f of files) {
        const full = path.join(ROOT, 'src', f);
        if (!fs.existsSync(full)) throw new Error('importScripts 找不到文件: ' + f);
        vm.runInContext(fs.readFileSync(full, 'utf8'), revived, { filename: 'src/' + f });
      }
    },
    addEventListener: function (type, fn) {
      if (myListeners[type]) myListeners[type].push(fn);
    },
    chrome: {
      runtime: {
        onInstalled: { addListener: (fn) => myListeners.onInstalled.push(fn) },
        onMessage: { addListener: (fn) => myListeners.onMessage.push(fn) }
      },
      tabs: {
        onUpdated: { addListener: (fn) => myListeners.onUpdated.push(fn) },
        onRemoved: { addListener: (fn) => myListeners.onRemoved.push(fn) },
        sendMessage: () => Promise.resolve()
      },
      storage: chromeStub.storage
    }
  };
  revived.self = revived;
  revived.globalThis = revived;
  vm.createContext(revived);
  vm.runInContext(fs.readFileSync(bgPath, 'utf8'), revived, { filename: 'src/background.js' });
  return { sandbox: revived, listeners: myListeners };
}

check('注册了 onMessage 监听', listeners.onMessage.length === 1, '数量=' + listeners.onMessage.length);
check('翻译模块已注入 worker 作用域', typeof sandbox.DSKTranslate === 'object' && typeof sandbox.DSKTranslate.translateText === 'function');
check('离线词库已注入 worker 作用域', typeof sandbox.DSKOfflineDict === 'object' && typeof sandbox.DSKOfflineDict.lookup === 'function');

/* ------------------------------ 用例 ------------------------------ */

function ask(payload) {
  return new Promise((resolve) => {
    let replied = false;
    const keepAlive = listeners.onMessage[0]({ type: 'DSK_TRANSLATE', payload }, {}, (res) => {
      replied = true;
      resolve(res);
    });
    setTimeout(() => {
      if (!replied) resolve({ timedOut: true, keepAlive });
    }, 3000);
  });
}

(async () => {
  // 1. 英文单词：应返回音标 + 释义（而不是 "translateText is not defined"）
  const r1 = await ask({ text: 'include' });
  check('单词翻译有应答', !r1.timedOut && !!r1, JSON.stringify(r1).slice(0, 80));
  check('应答 ok=true', !!(r1 && r1.ok), r1 && r1.error);
  check('拿到音标', !!(r1 && r1.data && r1.data.phonetic), r1 && r1.data && r1.data.phonetic);
  check('拿到释义', !!(r1 && r1.data && r1.data.meaning), r1 && r1.data && r1.data.meaning);
  check('没出现 translateText is not defined', !(r1 && r1.error && /translateText/.test(r1.error)), r1 && r1.error);

  // 2. 代码片段（非单词）：也应该能给出中文结果，不报错
  const r2 = await ask({ text: 'nclude <std' });
  check('代码片段不报错', !!(r2 && r2.ok), r2 && r2.error);

  // 3. 空内容：应明确报错而不是静默失败
  const r3 = await ask({ text: '   ' });
  check('空内容被拒绝', !!(r3 && !r3.ok && /没有可翻译/.test(r3.error)), r3 && r3.error);

  // 4. 自定义接口：设置里配好以后应优先使用
  storedOptions.options = {
    provider: 'custom',
    custom: { endpoint: 'https://custom.example.com/v1/chat/completions', apiKey: 'sk-test', model: 'test-model', prompt: '' },
    timeout: 5000,
    maxWords: 40
  };
  const r4 = await ask({ text: 'custom' });
  check('自定义接口可用', !!(r4 && r4.ok && r4.data), JSON.stringify(r4).slice(0, 100));
  check(
    '自定义接口结果被采用',
    !!(r4 && r4.data && r4.data.provider === 'custom' && /自定义接口返回的释义/.test(r4.data.meaning || '')),
    r4 && r4.data && (r4.data.provider + ' | ' + r4.data.meaning)
  );

  // 5. 自定义接口坏了 → 应回退到免费源，并且把失败原因留在提示里
  storedOptions.options = {
    provider: 'auto',
    custom: { endpoint: 'https://custom.example.com/v1/chat/completions', apiKey: '', model: 'x', prompt: '' },
    timeout: 5000,
    maxWords: 40
  };
  const r5 = await ask({ text: 'include' });
  check(
    '自定义接口失败后仍能出结果',
    !!(r5 && r5.ok && r5.data && r5.data.meaning),
    JSON.stringify((r5 && r5.data) || (r5 && r5.error) || '').slice(0, 100)
  );

  // 6. DSK_PROBE：设置页的「检测可用翻译源」应能拿到逐源结果
  const probe = await new Promise((resolve) => {
    listeners.onMessage[0]({ type: 'DSK_PROBE' }, {}, resolve);
  });
  check('诊断消息有应答', !!probe, JSON.stringify(probe).slice(0, 80));
  check('诊断返回了逐源结果', !!(probe && probe.ok && Array.isArray(probe.rows) && probe.rows.length >= 7), probe && probe.rows && probe.rows.length);
  const probeIds = (probe && probe.rows ? probe.rows : []).map((r) => r.id);
  check('诊断包含国内源（百度/有道）', probeIds.indexOf('baidu') >= 0 && probeIds.indexOf('youdao') >= 0, probeIds.join(','));
  check(
    '诊断包含离线词库（永远可用）',
    (probe.rows || []).some((r) => r.id === 'offline' && r.status === 'ok'),
    JSON.stringify((probe.rows || []).find((r) => r.id === 'offline'))
  );

  // 6b. 调试日志：应能导出「请求 → 返回」，否则用户没法反馈问题
  {
    const ask2 = (payload) => new Promise((resolve) => listeners.onMessage[0](payload, {}, resolve));
    const log = await ask2({ type: 'DSK_GET_LOG' });
    check('能导出调试日志', !!(log && log.ok && typeof log.text === 'string'), JSON.stringify(log).slice(0, 60));
    check('日志里有查询记录', /== 查询/.test(log.text), String(log.text).split('\n').slice(0, 3).join(' / '));
    check('日志里有返回原文', /<- 返回/.test(log.text), String(log.text).slice(0, 120));
    const cleared = await ask2({ type: 'DSK_CLEAR_LOG' });
    const after = await ask2({ type: 'DSK_GET_LOG' });
    check('能清空日志', !!(cleared && cleared.ok) && /暂无记录/.test(after.text), String(after.text).slice(0, 40));
  }

  // 6c. 日志要能扛住 Service Worker 被回收（重启后仍可导出）
  {
    const ask2 = (payload) => new Promise((resolve) => listeners.onMessage[0](payload, {}, resolve));
    await ask2({ type: 'DSK_TRANSLATE', payload: { text: 'include' } });
    await new Promise((r) => setTimeout(r, 600)); // 等日志落盘
    check('日志已写入 session 存储', !!LOG_STORE.dskLog && LOG_STORE.dskLog.length > 0, JSON.stringify(Object.keys(LOG_STORE)));
    // 模拟 worker 重启：另起一个干净的 worker，只有 session 存储保留
    const revived = reloadBackground();
    check('重启后的 worker 里翻译模块已加载', typeof revived.sandbox.DSKTranslate === 'object', typeof revived.sandbox.DSKTranslate);
    // 给 hydrate 一点时间（真实场景里 worker 启动后还要处理消息）
    await new Promise((r) => setTimeout(r, 300));
    const log2 = await new Promise((resolve) => revived.listeners.onMessage[0]({ type: 'DSK_GET_LOG' }, {}, resolve));
    check(
      '重启后仍能导出日志',
      !!(log2 && log2.ok && /== 查询/.test(log2.text || '')),
      JSON.stringify(log2).slice(0, 120) + ' | store=' + JSON.stringify(Object.keys(LOG_STORE))
    );
  }

  // 7. 模拟「Google / MyMemory 都被墙，只剩国内源」：翻译应该照样成功
  {
    const realFetch = sandbox.fetch;
    sandbox.fetch = async (url, init) => {
      if (url.indexOf('translate.google.com') >= 0 || url.indexOf('mymemory') >= 0) {
        throw new TypeError('Failed to fetch');
      }
      return realFetch(url, init);
    };
    storedOptions.options = { provider: 'free', custom: {}, timeout: 5000, maxWords: 40 };
    const r6 = await ask({ text: 'translation' });
    check('国外源全断时国内源顶上', !!(r6 && r6.ok && r6.data && /翻译/.test(r6.data.meaning || '')), JSON.stringify(r6 && r6.data).slice(0, 90));
    check('来源标注为国内源', !!(r6 && r6.data && /baidu|youdao/.test(r6.data.provider || '')), r6 && r6.data && r6.data.provider);
    sandbox.fetch = realFetch;
  }

  let failed = 0;
  for (const r of results) {
    if (!r.ok) failed++;
    console.log((r.ok ? '  ✓ ' : '  ✗ ') + r.name + (r.ok ? '' : '   → ' + r.extra));
  }
  console.log('\n' + (results.length - failed) + '/' + results.length + ' 项通过');
  process.exit(failed ? 1 : 0);
})();
