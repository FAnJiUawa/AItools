"""生成插件图标（仅开发时使用，图标已生成，无需重复运行）。
用法：python tools/make_icons.py
"""
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "icons"
OUT.mkdir(exist_ok=True)

BRAND = (77, 107, 254, 255)
BRAND_DARK = (58, 82, 220, 255)
WHITE = (255, 255, 255, 255)


def rounded(size, radius):
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle([0, 0, size - 1, size - 1], radius=radius, fill=BRAND)
    # 顶部一层浅色高光，视觉上更立体
    d.rounded_rectangle([0, 0, size - 1, int(size * 0.55)], radius=radius, fill=BRAND_DARK)
    d.rounded_rectangle([0, int(size * 0.30), size - 1, size - 1], radius=radius, fill=BRAND)
    return img


def load_font(px):
    for name in ("seguisb.ttf", "segoeuib.ttf", "arialbd.ttf", "msyhbd.ttc"):
        try:
            return ImageFont.truetype(name, px)
        except OSError:
            continue
    return ImageFont.load_default()


def draw_icon(size):
    img = rounded(size, max(4, int(size * 0.22)))
    d = ImageDraw.Draw(img)

    # 对话气泡
    pad = size * 0.17
    bubble = [pad, pad * 1.05, size - pad, size - pad * 1.5]
    d.rounded_rectangle(bubble, radius=size * 0.16, fill=WHITE)
    tail = [
        (pad + size * 0.14, bubble[3] - size * 0.02),
        (pad + size * 0.34, bubble[3] - size * 0.02),
        (pad + size * 0.16, bubble[3] + size * 0.15),
    ]
    d.polygon(tail, fill=WHITE)

    # 气泡里的「问号」，代表追问
    font = load_font(int(size * 0.46))
    text = "?"
    box = d.textbbox((0, 0), text, font=font)
    tx = (size - (box[2] - box[0])) / 2 - box[0]
    ty = (bubble[1] + bubble[3]) / 2 - (box[3] - box[1]) / 2 - box[1] - size * 0.045
    d.text((tx, ty), text, font=font, fill=BRAND_DARK)
    return img


for s in (16, 32, 48, 128):
    draw_icon(s).save(OUT / f"icon{s}.png")

print("icons written to", OUT)
