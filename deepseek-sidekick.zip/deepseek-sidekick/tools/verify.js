/* 自检脚本（不属于插件本体）：校验清单引用与模块导出是否对得上。
 * 用法： node tools/verify.js
 */
'use strict';
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const problems = [];

function rel(p) {
  return path.relative(ROOT, p).replace(/\\/g, '/');
}

// 1) manifest 引用的文件都要存在
const manifestPath = path.join(ROOT, 'manifest.json');
const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
const refs = [
  manifest.background && manifest.background.service_worker,
  manifest.options_ui && manifest.options_ui.page,
  ...((manifest.content_scripts || [])[0] || {}).js || [],
  ...((manifest.content_scripts || [])[0] || {}).css || [],
  ...Object.values(manifest.icons || {}),
  ...Object.values((manifest.action && manifest.action.default_icon) || {})
].filter(Boolean);

for (const r of refs) {
  if (!fs.existsSync(path.join(ROOT, r))) problems.push('manifest 引用了不存在的文件: ' + r);
}
if (manifest.manifest_version !== 3) problems.push('manifest_version 必须是 3');

// 2) content.js 用到的 UI / 网络成员必须真的导出了
function exportsOf(file, globalName) {
  const code = fs.readFileSync(path.join(ROOT, file), 'utf8');
  const start = code.indexOf('g.' + globalName + ' = {');
  if (start < 0) return null;
  const lines = code.slice(start).split('\n');
  const names = new Set();

  // 单行写法：g.DSKNet = { requestTranslate };
  const single = lines[0].trim().match(/^g\.(DSK[A-Za-z]+)\s*=\s*\{([^}\n]*)\};\s*$/);
  if (single) {
    for (const part of single[2].split(',')) {
      const name = part.trim().match(/^([A-Za-z_$][\w$]*)/);
      if (name) names.add(name[1]);
    }
    return names;
  }

  // 多行写法：逐行取键名，最后一项可能没有逗号
  for (let i = 1; i < lines.length; i++) {
    const line = lines[i].trim();
    if (line.startsWith('};')) break;
    if (!line) continue;
    const key = line.match(/^([A-Za-z_$][\w$]*)\s*[:,]?/);
    if (key) names.add(key[1]);
  }
  return names;
}

const uiExports = exportsOf('src/lib/ui.js', 'DSKUi');
const netExports = exportsOf('src/lib/net.js', 'DSKNet');
if (!uiExports) problems.push('没能在 src/lib/ui.js 里找到 g.DSKUi 导出块');
if (!netExports) problems.push('没能在 src/lib/net.js 里找到 g.DSKNet 导出块');
const contentCode = fs.readFileSync(path.join(ROOT, 'src/content.js'), 'utf8');

for (const [, name] of contentCode.matchAll(/DSKUi\.([A-Za-z_$][\w$]*)/g)) {
  if (uiExports && !uiExports.has(name)) problems.push('content.js 使用了未导出的 DSKUi.' + name);
}
for (const [, name] of contentCode.matchAll(/DSKNet\.([A-Za-z_$][\w$]*)/g)) {
  if (netExports && !netExports.has(name)) problems.push('content.js 使用了未导出的 DSKNet.' + name);
}

// 3) 离线词库条目格式检查
const dictCode = fs.readFileSync(path.join(ROOT, 'src/lib/offline-dict.js'), 'utf8');
const dictBody = dictCode.slice(dictCode.indexOf('const WORDS = {'), dictCode.indexOf('function lookup'));
const badEntries = [];
const entryRe = /^\s*([A-Za-z'’-]+):\s*\['([^']*)',\s*'([^']*)'\]/gm;
let count = 0;
let em;
while ((em = entryRe.exec(dictBody))) {
  count++;
  if (!em[2] || !em[3]) badEntries.push(em[1]);
}
for (const w of badEntries) problems.push('离线词库条目缺少音标或释义: ' + w);

// 4) 图标尺寸
const png = fs.readFileSync(path.join(ROOT, 'icons/icon128.png'));
const width = png.readUInt32BE(16);
const height = png.readUInt32BE(20);
if (width !== 128 || height !== 128) problems.push('icon128.png 尺寸不是 128x128 (' + width + 'x' + height + ')');

console.log('manifest 引用文件      : ' + refs.length + ' 个，全部存在');
console.log('DSKUi 导出成员         : ' + uiExports.size + ' 个（' + [...uiExports].join(', ') + '）');
console.log('DSKNet 导出成员        : ' + [...netExports].join(', '));
console.log('离线词库条目           : ' + count + ' 条');
console.log('icon128.png            : ' + width + 'x' + height);
console.log('');
if (problems.length) {
  console.log('发现 ' + problems.length + ' 个问题：');
  problems.forEach((p) => console.log('  × ' + p));
  process.exit(1);
}
console.log('✓ 全部检查通过');
