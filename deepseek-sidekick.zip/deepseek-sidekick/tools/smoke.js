/* 自检脚本（不属于插件本体）：用一个极简 DOM 打桩跑真实的 ui.js 逻辑，
 * 覆盖「按钮点击 → 打开面板 → 异步替换内容 → 关闭」这条主链路，不需要真浏览器。
 * 用法： node tools/smoke.js
 */
'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const ROOT = path.resolve(__dirname, '..');

/* ----------------------------- 极简 DOM 打桩 ----------------------------- */

let elementSeq = 0;

class ClassList {
  constructor(el) {
    this.el = el;
  }
  _set() {
    return new Set(String(this.el.className || '').split(/\s+/).filter(Boolean));
  }
  _write(set) {
    this.el.className = [...set].join(' ');
  }
  add(...names) {
    const s = this._set();
    names.forEach((n) => s.add(n));
    this._write(s);
  }
  remove(...names) {
    const s = this._set();
    names.forEach((n) => s.delete(n));
    this._write(s);
  }
  contains(name) {
    return this._set().has(name);
  }
}

class Element {
  constructor(tag) {
    this.tagName = String(tag || 'div').toUpperCase();
    this.nodeType = 1; // 元素节点
    this.id = '';
    this.className = '';
    this.style = { _p: {}, setProperty(k, v) { this._p[k] = v; } };
    this.children = [];
    this.parentNode = null;
    this.attributes = {};
    this.listeners = {};
    this.textContent = '';
    this.innerHTML = '';
    this.value = '';
    this.type = '';
    this.title = '';
    this.href = '';
    this.target = '';
    this.rel = '';
    this.rows = 0;
    this.scrollHeight = 10;
    this.isConnected = false;
    this.__seq = ++elementSeq;
    this.classList = new ClassList(this);
  }
  setAttribute(k, v) {
    this.attributes[k] = String(v);
    if (k === 'id') this.id = String(v);
  }
  getAttribute(k) {
    return this.attributes[k];
  }
  hasAttribute(k) {
    return Object.prototype.hasOwnProperty.call(this.attributes, k);
  }
  appendChild(child) {
    if (child.parentNode) child.parentNode.removeChild(child);
    child.parentNode = this;
    this.children.push(child);
    // 只要父节点在文档里（含 shadow root 情形），整棵子树都算已连通
    const parentConnected = this.isConnected || (this.isShadow && this.__host && this.__host.isConnected);
    if (this.isShadow && this.__host && !parentConnected) markConnected(this.__host, true);
    markConnected(child, true);
    return child;
  }
  removeChild(child) {
    const i = this.children.indexOf(child);
    if (i >= 0) this.children.splice(i, 1);
    child.parentNode = null;
    markConnected(child, false);
    if (child.isShadow && child.__host) markConnected(child.__host, false);
    return child;
  }
  remove() {
    if (this.parentNode) this.parentNode.removeChild(this);
  }
  addEventListener(type, fn) {
    (this.listeners[type] = this.listeners[type] || []).push(fn);
  }
  removeEventListener(type, fn) {
    const list = this.listeners[type] || [];
    const i = list.indexOf(fn);
    if (i >= 0) list.splice(i, 1);
  }
  dispatch(type, event) {
    (this.listeners[type] || []).slice().forEach((fn) => fn(Object.assign({ type, target: this, preventDefault() {}, stopPropagation() {} }, event || {})));
  }
  click() {
    this.dispatch('click');
  }
  focus() {
    doc.activeElement = this;
  }
  blur() {
    if (doc.activeElement === this) doc.activeElement = null;
  }
  querySelector(sel) {
    return this.querySelectorAll(sel)[0] || null;
  }
  querySelectorAll(sel) {
    const out = [];
    const match = (el) => {
      if (sel.startsWith('.')) return el.classList.contains(sel.slice(1));
      if (sel.startsWith('[')) {
        const m = sel.match(/^\[([\w-]+)(?:="([^"]*)")?\]$/);
        if (!m) return false;
        const v = el.attributes[m[1]];
        return m[2] === undefined ? v !== undefined : v === m[2];
      }
      return el.tagName === sel.toUpperCase();
    };
    const walk = (el) => {
      el.children.forEach((c) => {
        if (match(c)) out.push(c);
        walk(c);
      });
    };
    walk(this);
    return out;
  }
  getBoundingClientRect() {
    return this.__rect || { left: 0, top: 0, right: 0, bottom: 0, width: 0, height: 0 };
  }
  contains(node) {
    if (node === this) return true;
    if (node && node.__host === this) return true;
    if (this.__shadow && this.__shadow.contains(node)) return true;
    return this.children.some((c) => c.contains(node));
  }
  attachShadow() {
    const shadow = new Element('shadow-root');
    shadow.isShadow = true;
    shadow.__host = this;
    this.shadowRoot = shadow;
    this.__shadow = shadow;
    return shadow;
  }
  get firstChild() {
    return this.children[0] || null;
  }
  get lastChild() {
    return this.children[this.children.length - 1] || null;
  }
  get childNodes() {
    return this.children.slice();
  }
}

function markConnected(el, connected) {
  el.isConnected = connected;
  el.children.forEach((c) => markConnected(c, connected));
}

function collectAll(root, out) {
  out = out || [];
  (root.children || []).forEach((c) => {
    out.push(c);
    if (c.__shadow) collectAll(c.__shadow, out);
    collectAll(c, out);
  });
  return out;
}

const doc = {
  body: null,
  documentElement: null,
  activeElement: null,
  listeners: {},
  createElement(tag) {
    return new Element(tag);
  },
  getElementById(id) {
    return collectAll(doc.documentElement).find((el) => el.id === id) || null;
  },
  querySelector(sel) {
    return doc.documentElement.querySelector(sel) || doc.body.querySelector(sel);
  },
  addEventListener(type, fn) {
    (doc.listeners[type] = doc.listeners[type] || []).push(fn);
  },
  removeEventListener() {}
};
doc.body = new Element('body');
doc.documentElement = new Element('html');
doc.body.isConnected = true;
doc.documentElement.isConnected = true;
doc.documentElement.appendChild(doc.body);

const listeners = [];
const win = {
  innerWidth: 1280,
  innerHeight: 800,
  devicePixelRatio: 1,
  getSelection: () => selection,
  addEventListener(type, fn) {
    listeners.push({ type, fn });
  },
  removeEventListener() {},
  requestAnimationFrame: (fn) => setTimeout(fn, 0),
  cancelAnimationFrame: () => {},
  setTimeout,
  clearTimeout,
  console
};

const selection = {
  isCollapsed: true,
  rangeCount: 0,
  anchorNode: null,
  toString: () => '',
  removeAllRanges() {
    selection.rangeCount = 0;
    selection.isCollapsed = true;
  },
  addRange() {
    selection.rangeCount = 1;
    selection.isCollapsed = false;
  },
  getRangeAt() {
    return {
      getBoundingClientRect: () => selection.rect,
      cloneRange() {
        return this;
      },
      startContainer: selection.anchorNode
    };
  }
};

const sandbox = {
  console,
  setTimeout,
  clearTimeout,
  requestAnimationFrame: win.requestAnimationFrame,
  cancelAnimationFrame: win.cancelAnimationFrame,
  window: win,
  document: doc,
  navigator: { userAgent: 'node-smoke' },
  location: { search: '' },
  ResizeObserver: class {
    observe() {}
    disconnect() {}
  },
  Event: class {
    constructor(type, opts) {
      this.type = type;
      Object.assign(this, opts || {});
    }
  },
  KeyboardEvent: class {
    constructor(type, opts) {
      this.type = type;
      Object.assign(this, opts || {});
    }
  },
  Audio: class {
    play() {
      return Promise.resolve();
    }
    pause() {}
  },
  SpeechSynthesisUtterance: class {
    constructor(t) {
      this.text = t;
    }
  },
  speechSynthesis: { cancel() {}, speak() {} },
  Map,
  Set,
  Promise,
  Math,
  JSON,
  Date,
  Error,
  String,
  Number,
  Object,
  Array,
  Boolean,
  RegExp,
  isNaN,
  parseInt,
  parseFloat
};
sandbox.self = sandbox;
sandbox.globalThis = sandbox;
sandbox.window.document = doc;
sandbox.window.speechSynthesis = sandbox.speechSynthesis;
sandbox.window.Audio = sandbox.Audio;
sandbox.window.SpeechSynthesisUtterance = sandbox.SpeechSynthesisUtterance;
sandbox.window.ResizeObserver = sandbox.ResizeObserver;

vm.createContext(sandbox);
vm.runInContext(fs.readFileSync(path.join(ROOT, 'src/lib/ui.js'), 'utf8'), sandbox, { filename: 'src/lib/ui.js' });
const ui = sandbox.DSKUi || win.DSKUi;

/* ------------------------------- 断言 ------------------------------- */

const results = [];
function check(name, cond, extra) {
  results.push({ name, ok: !!cond, extra: extra === undefined ? '' : String(extra) });
}

function rect(left, top, width, height) {
  return { left, top, width, height, right: left + width, bottom: top + height };
}

// 无 DOM 也要能安全调用
check('导出 isSelectionInsideUi', typeof ui.isSelectionInsideUi === 'function');
check('未选中文字时返回空串', ui.getSelectionText() === '');

// 划词：显示按钮组
let asked = null;
let translated = null;
selection.rect = rect(100, 200, 160, 20);
selection.anchorNode = doc.body;
selection.addRange();
ui.showToolbar(selection.rect, 'virtual DOM diffing algorithm', {
  onAsk: (t) => (asked = t),
  onTranslate: (t) => (translated = t)
});
check('按钮组已创建', ui.hasToolbar());
const toolbar = ui.getToolbar();
check('按钮组挂在 host 里', !!toolbar && toolbar.isConnected);
check('按钮数量为 2', toolbar.children.length === 2, toolbar.children.length);
const toolbarRect = toolbar.getBoundingClientRect();
check('按钮组定位已生效', /px$/.test(toolbar.style.left) && toolbar.style.visibility === 'visible', toolbar.style.left + ',' + toolbar.style.visibility);

// 点击「追问」/「英文」应回传当前选中的文本
toolbar.children[0].click();
toolbar.children[1].click();
check('追问回调带回选中文本', asked === 'virtual DOM diffing algorithm', asked);
check('英文回调带回选中文本', translated === 'virtual DOM diffing algorithm', translated);

// 追问面板
const ask = ui.buildAskPanel('virtual DOM diffing algorithm', () => {}, ['解释这段话', '翻译成中文']);
check('追问面板含输入框', !!ask.textarea);
check('追问面板含快捷短语', ask.node.querySelectorAll('.dsk-chip').length === 2, ask.node.querySelectorAll('.dsk-chip').length);
check('追问面板含引用条', ask.node.querySelectorAll('.dsk-quote').length === 1);

const askPanel = ui.openPanel(toolbar, ask.node);
check('打开追问面板', askPanel.isConnected);
check('面板含关闭按钮', askPanel.querySelectorAll('.dsk-panel__close').length === 1);

// 翻译面板：loading -> 结果
const loadingPanel = ui.openPanel(toolbar, ui.buildLoadingPanel('translation'));
check('翻译 loading 面板已打开', loadingPanel.isConnected && loadingPanel.querySelectorAll('.dsk-loading').length === 1);
const resultNode = ui.buildResultPanel({
  input: 'translation',
  isWord: true,
  phonetic: 'trænzˈleɪʃn',
  audio: 'https://example.com/a.mp3',
  partOfSpeech: 'noun',
  meaning: '翻译；译文；转化',
  meanings: ['the process of translating words or text'],
  examples: [{ en: 'A good translation.', zh: '一个不错的译文。' }],
  note: '',
  provider: 'dictionaryapi.dev'
});
ui.replacePanelContent(loadingPanel, resultNode);
check('结果替换了 loading', loadingPanel.querySelectorAll('.dsk-loading').length === 0);
check('结果保留关闭按钮', loadingPanel.querySelectorAll('.dsk-panel__close').length === 1);
check('结果含音标', /trænz/.test(resultNode.querySelector('.dsk-phonetic').textContent));
check('结果含中文释义', /翻译/.test(resultNode.querySelector('.dsk-value').textContent));
check('结果含发音按钮', resultNode.querySelectorAll('.dsk-play').length === 1);
check('结果含例句', resultNode.querySelectorAll('.dsk-ex-en').length === 1);
check('结果标注来源', /dictionaryapi/.test(resultNode.querySelector('.dsk-foot').textContent));

// 查不到单词时的提示条
const missNode = ui.buildResultPanel({ input: 'recieve', isWord: true, phonetic: 'rɪˈsiːv', meaning: '收到', note: '你是不是想查 receive？', provider: 'offline' });
check('提示条正常渲染', missNode.querySelectorAll('.dsk-note').length === 1);

// 长文本走紧凑排版（阈值 28 个字符）
const longNode = ui.buildResultPanel({
  input: 'internationalization and localization',
  isWord: false,
  phonetic: '',
  meaning: '国际化与本地化',
  provider: 'google'
});
check('长文本使用紧凑排版', longNode.classList.contains('dsk-result--long'));
const shortNode = ui.buildResultPanel({ input: 'translation', isWord: true, phonetic: '', meaning: '翻译', provider: 'google' });
check('普通单词不触发紧凑排版', !shortNode.classList.contains('dsk-result--long'));

// 关闭面板 / 收起按钮
ui.closePanel();
check('关闭面板后已移除', !loadingPanel.isConnected);
ui.hideToolbar();
check('按钮组已收起', !ui.hasToolbar());

// 选区在我们自己的浮层里时不应误判
const probePanel = ui.openPanel(toolbar, ui.buildAskPanel('hello', () => {}).node);
check('探针面板已打开', probePanel.isConnected);
if (process.env.DSK_SMOKE_DEBUG) {
  const hostEl = doc.getElementById('dsk-sidekick-root');
  const quote = probePanel.querySelector('.dsk-quote');
  console.log('   debug host:', !!hostEl, 'quote:', !!quote, 'host.contains(quote):', hostEl && hostEl.contains(quote));
  console.log('   debug activeElement === 探针输入框:', doc.activeElement === probePanel.querySelector('[data-dsk="input"]'));
  console.log('   debug host.contains(activeElement):', hostEl && hostEl.contains(doc.activeElement));
}
selection.isCollapsed = false;
selection.anchorNode = probePanel.querySelector('.dsk-quote');
check('浮层内选区被识别', ui.isSelectionInsideUi() === true);
selection.anchorNode = doc.body;
check('页面内选区不误判为浮层', ui.isSelectionInsideUi() === false);
doc.activeElement = probePanel.querySelector('[data-dsk="input"]');
selection.isCollapsed = true;
selection.anchorNode = null;
check('焦点在浮层输入框时被识别', ui.isSelectionInsideUi() === true);
// 页面自己的控件也可能被包在宿主里，不能据此认为是我们的浮层
const foreign = doc.createElement('textarea');
foreign.setAttribute('placeholder', '给 DeepSeek 发送消息');
doc.getElementById('dsk-sidekick-root').appendChild(foreign);
doc.activeElement = foreign;
check('宿主内的页面控件不被误判', ui.isSelectionInsideUi() === false);
foreign.remove();
doc.activeElement = doc.body;
check('焦点回到页面后不再认为是浮层', ui.isSelectionInsideUi() === false);
ui.closePanel();

/* ------------------------------- 汇总 ------------------------------- */

let failed = 0;
for (const r of results) {
  if (!r.ok) failed++;
  console.log((r.ok ? '  ✓ ' : '  ✗ ') + r.name + (r.ok ? '' : '   → ' + r.extra));
}
console.log('\n' + (results.length - failed) + '/' + results.length + ' 项通过');
process.exit(failed ? 1 : 0);
