/* 自检脚本（不属于插件本体）：在 Node 里桩掉浏览器 API，跑通翻译核心逻辑。
 * 用法： node tools/check.js
 */
'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const ROOT = path.resolve(__dirname, '..');
const files = ['src/lib/offline-dict.js', 'src/lib/translate.js'];

const sandbox = {
  console: console,
  setTimeout: setTimeout,
  clearTimeout: clearTimeout,
  URL: URL,
  encodeURIComponent: encodeURIComponent,
  AbortController: AbortController,
  Math: Math,
  JSON: JSON,
  Map: Map,
  Set: Set,
  Array: Array,
  Object: Object,
  String: String,
  Number: Number,
  Boolean: Boolean,
  Promise: Promise,
  RegExp: RegExp,
  Date: Date,
  Error: Error,
  TypeError: TypeError,
  WeakMap: WeakMap,
  isNaN: isNaN,
  parseInt: parseInt,
  parseFloat: parseFloat
};
sandbox.self = sandbox;
sandbox.globalThis = sandbox;

/* ---------------------------- 桩 ---------------------------- */

const calls = [];
function makeResponse(body, status) {
  const code = status || 200;
  return {
    ok: code >= 200 && code < 300,
    status: code,
    text: async () => (typeof body === 'string' ? body : JSON.stringify(body)),
    json: async () => (typeof body === 'string' ? JSON.parse(body) : body)
  };
}

const DICT_JSON = [
  {
    word: 'translation',
    phonetic: '/trænzˈleɪʃn/',
    phonetics: [
      { text: '/trænzˈleɪʃn/', audio: '' },
      { text: '/trænsˈleɪʃən/', audio: '//ssl.gstatic.com/dictionary/static/sounds/20200429/translation--_gb_1.mp3' }
    ],
    meanings: [
      {
        partOfSpeech: 'noun',
        definitions: [
          {
            definition: 'the process of translating words or text from one language into another.',
            example: 'the translation of the Bible into English'
          },
          { definition: 'a written or spoken rendering of the meaning of a word or text in another language.' }
        ]
      }
    ]
  }
];

const GOOGLE_BODY = JSON.stringify([
  [['虚拟 DOM 差异比较算法', 'virtual DOM diffing algorithm', null, null, 10], ['ˈvɜːtʃuəl dɒm', 'virtual DOM', null, null, null]],
  null,
  'en',
  null,
  null,
  null,
  null,
  []
]);

const MYMEMORY = { responseData: { translatedText: '这是一个测试句子。' } };

sandbox.fetch = async (url) => {
  calls.push(url);
  if (url.indexOf('api.dictionaryapi.dev') >= 0) {
    if (url.indexOf('translation') >= 0) return makeResponse(DICT_JSON, 200);
    return makeResponse('<html>No Definitions Found</html>', 404);
  }
  if (url.indexOf('translate.google.com') >= 0) {
    if (url.indexOf('phase-locked') >= 0) {
      return makeResponse(JSON.stringify([[['', 'phase-locked', null, null, 10]], null, 'en']), 200);
    }
    return makeResponse(GOOGLE_BODY, 200);
  }
  if (url.indexOf('mymemory') >= 0) {
    if (url.indexOf('phase-locked') >= 0) return makeResponse({ responseData: { translatedText: '' } }, 200);
    return makeResponse(MYMEMORY, 200);
  }
  throw new TypeError('Failed to fetch');
};

vm.createContext(sandbox);
files.forEach((f) => {
  vm.runInContext(fs.readFileSync(path.join(ROOT, f), 'utf8'), sandbox, { filename: f });
});

const T = sandbox.DSKTranslate;

/* ---------------------------- 断言 ---------------------------- */

const results = [];
function check(name, cond, extra) {
  results.push({ name: name, ok: !!cond, extra: extra === undefined ? '' : String(extra) });
}

(async () => {
  /* 1. 常见单词：离线词库立刻命中 */
  const hello = await T.translateText('hello', { options: { provider: 'auto' } });
  check('hello 有音标', hello.phonetic === 'həˈləʊ', hello.phonetic);
  check('hello 有中文', /你好/.test(hello.meaning), hello.meaning);

  /* 2. 单词：词典音标 + 中文 + 例句 + 发音 */
  const tr = await T.translateText(' translation ', { options: { provider: 'auto' } });
  check('translation 音标来自词典', /^træn[sz]/.test(tr.phonetic), tr.phonetic);
  check('translation 有中文释义', !!tr.meaning && !/^[A-Za-z\s.,'-]+$/.test(tr.meaning), tr.meaning);
  check('translation 发音转为 https', tr.audio.indexOf('https://') === 0, tr.audio);
  check('translation 有词性', !!tr.partOfSpeech, tr.partOfSpeech);
  check('translation 有英文释义', tr.meanings.length > 0, JSON.stringify(tr.meanings).slice(0, 80));
  check('translation 有例句', tr.examples.length > 0 && !!tr.examples[0].en, JSON.stringify(tr.examples).slice(0, 80));

  /* 3. 明显打错的词：给出拼写建议 */
  const rec = await T.translateText('recieve', { options: { provider: 'auto' } });
  check('recieve 给出拼写建议', /receive/.test(rec.note || '') || !!rec.meaning, rec.note + ' | ' + rec.meaning);

  /* 4. 短语：走整句翻译（桩里 Google/MyMemory 都能给出中文） */
  const phrase = await T.translateText('virtual DOM diffing algorithm', { options: { provider: 'auto' } });
  check('短语有中文', /虚拟|测试句子/.test(phrase.meaning), phrase.meaning);
  check('短语标记为非单词', phrase.isWord === false);

  /* 5. 纯离线模式：不联网 */
  calls.length = 0;
  const off = await T.translateText('browser', { options: { provider: 'offline' } });
  check('离线模式有结果', !!off.meaning && !!off.phonetic, off.meaning);
  check('离线模式零网络请求', calls.length === 0, 'calls=' + calls.length);

  /* 6. 超长文本被截断 */
  const long = await T.translateText(new Array(80).fill('word').join(' '), { options: { provider: 'auto', maxWords: 10 } });
  check('超长文本被截断', long.input.split(' ').length <= 12, long.input.slice(-20));

  /* 7. 空输入被拒绝 */
  let threw = false;
  try {
    await T.translateText('', { options: {} });
  } catch (_) {
    threw = true;
  }
  check('空输入被拒绝', threw);

  /* 8. 结果缓存 */
  calls.length = 0;
  await T.translateText('translation', { options: { provider: 'auto' } });
  check('结果命中缓存', calls.length === 0, 'calls=' + calls.length);

  /* 8b. 单词路径要「先中文、后音标」，并且音标只在真有重音符号时才采用 */
  {
    T.resetDownSources();
    const realFetch = sandbox.fetch;
    const order = [];
    sandbox.fetch = async (url) => {
      calls.push(url);
      if (url.indexOf('translate.google.com') >= 0) {
        order.push('google');
        throw new TypeError('Failed to fetch');
      }
      if (url.indexOf('mymemory') >= 0) {
        order.push('mymemory');
        return makeResponse({ responseData: { translatedText: '合成的；人造的' } }, 200);
      }
      if (url.indexOf('api.dictionaryapi.dev') >= 0) {
        order.push('dict');
        return makeResponse(
          [
            {
              word: 'synthetic',
              phonetics: [{ text: '/sɪnˈθetɪk/', audio: '//example.com/s.mp3' }],
              meanings: [{ partOfSpeech: 'adj', definitions: [{ definition: 'made by chemical synthesis' }] }]
            }
          ],
          200
        );
      }
      throw new TypeError('Failed to fetch');
    };
    const r = await T.translateText('syntheticzz', { options: { provider: 'auto' } });
    check('单词能从可达源拿到中文', /合成/.test(r.meaning || ''), r.meaning);
    check('中文来源排在词典前面', order.indexOf('mymemory') < order.indexOf('dict'), order.join(' → '));
    check('随后补上了音标', r.phonetic === 'sɪnˈθetɪk', r.phonetic);
    check('发音链接转成了 https', r.audio.indexOf('https://') === 0, r.audio);
    sandbox.fetch = realFetch;
  }

  /* 8c. 「补音标」必须有独立短预算：词典源卡住时不能拖住整次查询 */
  {
    T.resetDownSources();
    const realFetch = sandbox.fetch;
    let aborted = false;
    sandbox.fetch = async (url, init) => {
      calls.push(url);
      if (url.indexOf('api.dictionaryapi.dev') >= 0) {
        // 模拟一个卡住的请求：只在被 abort 时才结束
        return new Promise((resolve, reject) => {
          const sig = init && init.signal;
          const t = setTimeout(() => resolve(makeResponse([], 200)), 30000);
          if (sig) {
            sig.addEventListener('abort', () => {
              aborted = true;
              clearTimeout(t);
              const err = new Error('The user aborted a request.');
              err.name = 'AbortError';
              reject(err);
            });
          }
        });
      }
      if (url.indexOf('mymemory') >= 0) {
        return makeResponse({ responseData: { translatedText: '索引' } }, 200);
      }
      throw new TypeError('Failed to fetch');
    };
    const t0 = Date.now();
    const r = await T.translateText('indexzz', { options: { provider: 'auto', phoneticTimeout: 600 } });
    const cost = Date.now() - t0;
    check('释义照常拿到', /索引/.test(r.meaning || ''), r.meaning);
    check('卡住的音标源没有拖慢查询（<3s）', cost < 3000, cost + ' ms');
    check('预算到点真的取消了请求', aborted === true, String(aborted));
    sandbox.fetch = realFetch;
  }

  /* 9. 代码片段：逐词释义 */
  const frag = await T.translateText('phase <std', { options: { provider: 'auto' } });
  check('代码片段给出逐词释义', !!frag.meaning, JSON.stringify(frag.meaning).slice(0, 60));
  check('代码片段附上说明', /逐个给出释义/.test(frag.note || ''), frag.note);

  /* 10. 大写开头的正常单词：必须按单词处理，且不能误报拼写错误 */
  const cap = await T.translateText('Phase', { options: { provider: 'auto' } });
  check('大写单词仍按单词处理', cap.isWord === true, String(cap.isWord));
  check('大写单词给出音标', !!cap.phonetic, cap.phonetic);
  check('大写单词给出释义', !!cap.meaning, cap.meaning);
  check('大写单词不再误报拼写错误', !/拼写有误/.test(cap.note || ''), cap.note);

  /* 11. 常见词不应触发拼写建议 */
  const shortWords = ['has', 'loop', 'clock', 'source'];
  for (const w of shortWords) {
    const r = await T.translateText(w, { options: { provider: 'auto' } });
    check('「' + w + '」不误报拼写错误', !/拼写有误/.test(r.note || ''), r.note || r.meaning);
  }

  /* 12. 大写开头的短句仍走整句翻译 */
  const capSent = await T.translateText('Enable the internal clock source', { options: { provider: 'auto' } });
  check('大写短句仍走整句翻译', !/逐个给出释义/.test(capSent.note || ''), capSent.note + ' | ' + capSent.meaning);

  /* 13. 连字符组合词：拆开给各段意思 */
  const hyph = await T.translateText('phase-locked', { options: { provider: 'auto' } });
  check('连字符词拆分给意思', /相位|阶段/.test(hyph.meaning || ''), hyph.meaning);
  check('连字符词附上说明', /各组成部分/.test(hyph.note || ''), hyph.note);

  /* 14. 死源冷却：连不上的源要被临时跳过，第二次查词不该再白等 */
  {
    const realFetch = sandbox.fetch;
    T.resetDownSources();
    sandbox.fetch = async (url) => {
      calls.push(url);
      if (url.indexOf('mymemory') >= 0) return makeResponse({ responseData: { translatedText: '电的；用电的' } }, 200);
      throw new TypeError('Failed to fetch');
    };
    calls.length = 0;
    const first = await T.translateText('zzqalpha', { options: { provider: 'auto' } });
    const firstCalls = calls.length;
    calls.length = 0;
    const second = await T.translateText('zzqbeta', { options: { provider: 'auto' } });
    check('可达源能给出结果（第一次）', /电的/.test(first.meaning || ''), first.meaning);
    check('可达源能给出结果（第二次）', /电的/.test(second.meaning || ''), second.meaning);
    check('第二次请求数变少（连不上的源被跳过）', calls.length < firstCalls, '第一次 ' + firstCalls + ' → 第二次 ' + calls.length);
    sandbox.fetch = realFetch;
  }

  /* 15. 片段逐词释义：整句源全断时退化为逐词 */
  {
    const realFetch = sandbox.fetch;
    T.resetDownSources();
    sandbox.fetch = async (url) => {
      calls.push(url);
      if (url.indexOf('api.dictionaryapi.dev') >= 0) {
        return url.indexOf('include') >= 0
          ? makeResponse(
              [
                {
                  word: 'include',
                  phonetics: [],
                  meanings: [{ partOfSpeech: 'verb', definitions: [{ definition: 'comprise or contain as part of a whole' }] }]
                }
              ],
              200
            )
          : makeResponse({}, 404);
      }
      throw new TypeError('Failed to fetch');
    };
    const r = await T.translateText('include <stdiozzz', { options: { provider: 'auto' } });
    check('整句源全断时退化为逐词', !!(r.meaning && /include/.test(r.meaning)), JSON.stringify(r.meaning) + ' | ' + (r.note || ''));
    check('并说明这是逐词结果', /逐个给出释义/.test(r.note || ''), r.note);
    sandbox.fetch = realFetch;
  }

  let failed = 0;
  for (const r of results) {
    if (!r.ok) failed++;
    console.log((r.ok ? '  OK   ' : '  FAIL ') + r.name + (r.ok ? '' : '   -> ' + r.extra));
  }
  console.log('\n' + (results.length - failed) + '/' + results.length + ' 项通过');
  process.exit(failed ? 1 : 0);
})();
