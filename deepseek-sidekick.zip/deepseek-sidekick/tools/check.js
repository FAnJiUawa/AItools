/* 自检脚本（不属于插件本体）：在 Node 里桩掉浏览器 API，跑通翻译核心逻辑。
 * 用法： node tools/check.js
 */
'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const ROOT = path.resolve(__dirname, '..');
const files = [
  'src/lib/offline-dict.js',
  'src/lib/translate.js'
];

const sandbox = {
  console,
  setTimeout,
  clearTimeout,
  URL,
  encodeURIComponent,
  AbortController,
  JSON,
  Map,
  Set,
  Array,
  Object,
  String,
  Number,
  Boolean,
  Math,
  Promise,
  RegExp,
  Date,
  Error,
  TypeError,
  isNaN,
  parseInt,
  parseFloat
};
sandbox.self = sandbox;
sandbox.globalThis = sandbox;

// ---- 桩 1：fetch，按 URL 返回固定响应 ----
const calls = [];
function makeResponse(body, status) {
  return {
    ok: status >= 200 && status < 300,
    status,
    text: async () => (typeof body === 'string' ? body : JSON.stringify(body)),
    json: async () => (typeof body === 'string' ? JSON.parse(body) : body)
  };
}

const DICT_JSON = [
  {
    word: 'translation',
    phonetic: '/trænzˈleɪʃn/',
    phonetics: [
      { text: '/trænzˈleɪʃn/', audio: '' },
      { text: '/trænsˈleɪʃən/', audio: '//ssl.gstatic.com/dictionary/static/sounds/20200429/translation--_gb_1.mp3' }
    ],
    meanings: [
      {
        partOfSpeech: 'noun',
        definitions: [
          { definition: 'the process of translating words or text from one language into another.', example: 'the translation of the Bible into English' },
          { definition: 'a written or spoken rendering of the meaning of a word or text in another language.' }
        ]
      }
    ]
  }
];

const GOOGLE_BODY = JSON.stringify([
  [
    ['虚拟 DOM 差异比较算法', 'virtual DOM diffing algorithm', null, null, 10],
    ['ˈvɜːtʃuəl dɒm', 'virtual DOM', null, null, null]
  ],
  null,
  'en',
  null,
  null,
  null,
  null,
  []
]);

const MYMEMORY = { responseData: { translatedText: '这是一个测试句子。' } };

sandbox.fetch = async (url) => {
  calls.push(url);
  if (url.indexOf('api.dictionaryapi.dev') >= 0) {
    if (url.indexOf('translation') >= 0) return makeResponse(DICT_JSON, 200);
    if (url.indexOf('recieve') >= 0) return makeResponse('<html>No Definitions Found</html>', 404);
    if (url.indexOf('hello') >= 0) return makeResponse('<html>No Definitions Found</html>', 404);
    return makeResponse({}, 404);
  }
  if (url.indexOf('translate.google.com') >= 0) {
    // 连字符词：模拟整句翻译也给不出有效译文
    if (url.indexOf('phase-locked') >= 0) {
      return makeResponse(JSON.stringify([[['', 'phase-locked', null, null, 10]], null, 'en']), 200);
    }
    return makeResponse(GOOGLE_BODY, 200);
  }
  if (url.indexOf('mymemory') >= 0) {
    if (url.indexOf('phase-locked') >= 0) return makeResponse({ responseData: { translatedText: '' } }, 200);
    return makeResponse(MYMEMORY, 200);
  }
  throw new Error('unexpected url ' + url);
};

// ---- 桩 2：chrome 无关部分不需要，translate.js 只依赖 fetch / DSKOfflineDict ----
vm.createContext(sandbox);
for (const f of files) {
  const code = fs.readFileSync(path.join(ROOT, f), 'utf8');
  vm.runInContext(code, sandbox, { filename: f });
}

const T = sandbox.DSKTranslate;
const results = [];

function check(name, cond, extra) {
  results.push({ name, ok: !!cond, extra: extra || '' });
}

(async () => {
  // 1. 常见单词：离线词库应立刻命中（音标 + 中文）
  const hello = await T.translateText('hello', { options: { provider: 'auto' } });
  check('hello 有音标', hello.phonetic === 'həˈləʊ', JSON.stringify(hello.phonetic));
  check('hello 有中文', /你好/.test(hello.meaning), hello.meaning);

  // 2. 单词：应拿到 dictionaryapi 的音标、中文（Google 兜底）、词性、例句、真人发音
  const tr = await T.translateText(' translation ', { options: { provider: 'auto' } });
  check('translation 音标来自词典', tr.phonetic.indexOf('trænz') === 0 || tr.phonetic.indexOf('træns') === 0, tr.phonetic);
  check('translation 有中文释义', !!tr.meaning && !/^[A-Za-z\s.,'-]+$/.test(tr.meaning), tr.meaning);
  check('translation 发音转为 https', tr.audio.startsWith('https://'), tr.audio);
  check('translation 有词性', tr.partOfSpeech === 'noun' || !!tr.partOfSpeech, tr.partOfSpeech);
  check('translation 有英文释义', tr.meanings.length > 0, JSON.stringify(tr.meanings).slice(0, 80));
  check('translation 有例句', tr.examples.length > 0 && !!tr.examples[0].en, JSON.stringify(tr.examples).slice(0, 80));

  // 3. 查不到的单词：应给出拼写建议
  const rec = await T.translateText('recieve', { options: { provider: 'auto' } });
  check('recieve 给出拼写建议', /receive/.test(rec.note || '') || !!rec.meaning, rec.note + ' | ' + rec.meaning);

  // 4. 短语：走 Google / MyMemory，拿到中文整句
  const phrase = await T.translateText('virtual DOM diffing algorithm', { options: { provider: 'auto' } });
  check('短语有中文', /虚拟/.test(phrase.meaning), phrase.meaning);
  check('短语标记为非单词', phrase.isWord === false);

  // 5. 纯离线模式：不联网
  calls.length = 0;
  const off = await T.translateText('browser', { options: { provider: 'offline' } });
  check('离线模式有结果', !!off.meaning && !!off.phonetic, off.meaning);
  check('离线模式零网络请求', calls.length === 0, 'calls=' + calls.length);

  // 6. 超长文本会被截断
  const long = await T.translateText(new Array(80).fill('word').join(' '), { options: { provider: 'auto', maxWords: 10 } });
  check('超长文本被截断', long.input.split(' ').length <= 12, long.input.slice(-20));

  // 7. 空输入应报错
  let threw = false;
  try {
    await T.translateText('', { options: {} });
  } catch (e) {
    threw = true;
  }
  check('空输入被拒绝', threw);

  // 8. 缓存：同样的词第二次不应再发请求
  calls.length = 0;
  await T.translateText('translation', { options: { provider: 'auto' } });
  check('结果命中缓存', calls.length === 0, 'calls=' + calls.length);

  // 9. 代码片段（不是完整单词也不是自然语句）：应逐个单词给释义，而不是直接报查不到
  const frag = await T.translateText('nclude <std', { options: { provider: 'auto' } });
  check('代码片段给出逐词释义', !!frag.meaning, JSON.stringify(frag.meaning).slice(0, 60));
  check('代码片段附上说明', /逐个给出释义/.test(frag.note || ''), frag.note);

  // 10. 大写开头的正常单词：必须按单词处理，且绝不能提示"你是不是想查 has"
  const cap = await T.translateText('Phase', { options: { provider: 'auto' } });
  check('大写单词仍按单词处理', cap.isWord === true, String(cap.isWord));
  check('大写单词给出音标', !!cap.phonetic, cap.phonetic);
  check('大写单词给出释义', !!cap.meaning, cap.meaning);
  check('大写单词不再误报拼写错误', !/拼写有误/.test(cap.note || ''), cap.note);

  // 11. 极短词/常见词不应触发拼写建议
  for (const w of ['has', 'loop', 'clock', 'source']) {
    const r = await T.translateText(w, { options: { provider: 'auto' } });
    check('「' + w + '」不误报拼写错误', !/拼写有误/.test(r.note || ''), r.note || r.meaning);
  }

  // 12. 大写开头的短句仍按整句翻译
  const capSent = await T.translateText('Enable the internal clock source', { options: { provider: 'auto' } });
  check('大写短句仍走整句翻译', !/逐个给出释义/.test(capSent.note || ''), capSent.note + ' | ' + capSent.meaning);

  // 13. 连字符组合词：拆开给各段意思，而不是一句"查不到"
  const hyph = await T.translateText('phase-locked', { options: { provider: 'auto' } });
  check('连字符词拆分给意思', /相位|阶段/.test(hyph.meaning || ''), hyph.meaning);
  check('连字符词附上说明', /各组成部分/.test(hyph.note || ''), hyph.note);

  let failed = 0;
  for (const r of results) {
    if (!r.ok) failed++;
    console.log((r.ok ? '  ✓ ' : '  ✗ ') + r.name + (r.ok ? '' : '   → ' + r.extra));
  }
  console.log('\n' + (results.length - failed) + '/' + results.length + ' 项通过');
  process.exit(failed ? 1 : 0);
})();
