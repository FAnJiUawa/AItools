@echo off
chcp 65001 >nul
title DeepSeek Sidekick - Installer
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0一键安装.ps1"