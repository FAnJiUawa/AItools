/* DeepSeek 划词助手 - 后台 Service Worker
 * 作用：代理词典 / 翻译网络请求（不受页面 CORS 限制），带超时与多源回退。
 *
 * 注意：MV3 的 service worker 只会执行 manifest 里 background.service_worker 指定的这一个文件，
 * content_scripts 里那些 js 不会自动加载进来，所以这里必须显式 importScripts。
 * importScripts 只能在顶层同步调用，且必须写在这两个文件的顶部。
 */
importScripts('lib/offline-dict.js', 'lib/cn-dict.js', 'lib/translate.js');

self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', (e) => e.waitUntil(self.clients.claim()));

// Service Worker 每次被唤醒时，把上次留在 session 存储里的调试日志 / 死源记录读回来
try {
  if (self.DSKTranslate && typeof self.DSKTranslate.hydrate === 'function') {
    self.DSKTranslate.hydrate();
  }
} catch (_) {}
self.addEventListener('unhandledrejection', (e) => {
  try {
    e.preventDefault();
  } catch (_) {}
});

/** 待自动发送的追问内容：标签页 id -> { text, at } */
const pending = new Map();
const retryTimers = new Map();

chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install') {
    chrome.storage.sync.get({ options: null }, (v) => {
      if (!v.options) {
        chrome.storage.sync.set({
          options: {
            provider: 'auto',
            custom: { endpoint: '', apiKey: '', model: '', prompt: '' },
            timeout: 9000,
            maxWords: 40
          }
        });
      }
    });
  }
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg) return false;

  if (msg.type === 'DSK_TRANSLATE') {
    handleTranslate(msg.payload || {})
      .then((data) => sendResponse({ ok: true, data }))
      .catch((err) => sendResponse({ ok: false, error: (err && err.message) || String(err) }));
    return true; // 异步响应
  }

  if (msg.type === 'DSK_PROBE') {
    // 诊断：逐个探测各翻译源在当前网络下是否可用
    getOptions()
      .then((options) => self.DSKTranslate.probeSources(options, options.timeout || 8000))
      .then((rows) => sendResponse({ ok: true, rows }))
      .catch((err) => sendResponse({ ok: false, error: (err && err.message) || String(err) }));
    return true;
  }

  if (msg.type === 'DSK_GET_LOG') {
    // 导出调试日志：让用户把「请求 → 返回」原文发出来定位
    Promise.resolve()
      .then(() => self.DSKTranslate.getDebugLog())
      .then((text) => sendResponse({ ok: true, text: text || '' }))
      .catch((err) => sendResponse({ ok: false, error: (err && err.message) || String(err) }));
    return true;
  }

  if (msg.type === 'DSK_CLEAR_LOG') {
    Promise.resolve()
      .then(() => self.DSKTranslate.clearDebugLog())
      .then(() => sendResponse({ ok: true }))
      .catch(() => sendResponse({ ok: true }));
    return true;
  }

  if (msg.type === 'DSK_SEND_TO_NEW_CHAT') {
    // 记住「当前标签页即将开新对话，需要自动发送这段话」，页面加载完成后投递
    pending.set(sender && sender.tab && sender.tab.id, {
      text: String(msg.text || ''),
      at: Date.now()
    });
    return false;
  }

  if (msg.type === 'DSK_TAB_READY') {
    // 新对话页的内容脚本就绪了，如果它正是我们要补发的标签页，就把内容投递过去
    deliverPending(sender && sender.tab && sender.tab.id);
    return false;
  }

  return false;
});

/* 待自动发送的追问内容：标签页 id -> { text, at }（在文件上方声明） */

/** 把待发送内容投递给内容脚本；失败则按退避策略重试几次 */
function deliverPending(tabId, attempt) {
  const item = pending.get(tabId);
  if (!item) return;
  const tries = attempt || 0;
  if (Date.now() - item.at > 120000) {
    pending.delete(tabId);
    return;
  }
  chrome.tabs.sendMessage(tabId, { type: 'DSK_PREFILL', text: item.text, autoSend: true }).then(
    () => {
      // 投递成功：清掉待发状态并取消可能存在的重试
      pending.delete(tabId);
      clearRetry(tabId);
    },
    () => {
      if (tries < 6) scheduleRetry(tabId, tries + 1);
    }
  );
}

function scheduleRetry(tabId, nextAttempt) {
  if (retryTimers.has(tabId)) return; // 已经有重试在排队
  const delay = 400 + nextAttempt * 500;
  const timer = setTimeout(() => {
    retryTimers.delete(tabId);
    deliverPending(tabId, nextAttempt);
  }, delay);
  retryTimers.set(tabId, timer);
}

function clearRetry(tabId) {
  const timer = retryTimers.get(tabId);
  if (timer) {
    clearTimeout(timer);
    retryTimers.delete(tabId);
  }
}

chrome.tabs.onUpdated.addListener((tabId, info, tab) => {
  if (info.status !== 'complete') return;
  if (!pending.has(tabId)) return;
  if (!tab || !/^https:\/\/chat\.deepseek\.com\//.test(tab.url || '')) {
    pending.delete(tabId);
    clearRetry(tabId);
    return;
  }
  deliverPending(tabId, 0);
});

chrome.tabs.onRemoved.addListener((tabId) => {
  pending.delete(tabId);
  clearRetry(tabId);
});

async function handleTranslate(payload) {
  const options = await getOptions();
  const text = String((payload && payload.text) || '')
    .replace(/\s+/g, ' ')
    .trim();
  if (!text) throw new Error('没有可翻译的内容');
  // 显式从 DSKTranslate 取，不依赖 importScripts 带来的隐式全局变量
  const api = self.DSKTranslate;
  if (!api || typeof api.translateText !== 'function') {
    throw new Error('翻译模块未加载（请重新加载扩展）');
  }
  return api.translateText(text, { options, timeoutMs: options.timeout || 9000 });
}

function getOptions() {
  return new Promise((resolve) => {
    let settled = false;
    const timer = setTimeout(() => {
      if (!settled) {
        settled = true;
        resolve(defaultOptions());
      }
    }, 1500);
    try {
      chrome.storage.sync.get({ options: null }, (v) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        resolve(Object.assign(defaultOptions(), v && v.options ? v.options : {}));
      });
    } catch (_) {
      if (!settled) {
        settled = true;
        clearTimeout(timer);
        resolve(defaultOptions());
      }
    }
  });
}

function defaultOptions() {
  return {
    provider: 'auto',
    custom: { endpoint: '', apiKey: '', model: '', prompt: '' },
    timeout: 9000,
    maxWords: 40
  };
}
