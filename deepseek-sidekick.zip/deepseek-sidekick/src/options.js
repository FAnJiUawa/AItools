/* 设置页逻辑 */
'use strict';

const DEFAULT_PROMPT = `你是一名英汉词典助手，只输出 JSON，不要输出解释或代码块标记。
判断输入是「单个单词」还是「短语/句子」，按下面两种格式之一输出：
· 单个单词：{"phonetic":"音标，带斜杠","meaning":"简体中文释义，多个义项用；分隔","partOfSpeech":"词性","examples":[{"en":"英文例句","zh":"中文翻译"}],"note":""}
· 短语或句子：{"phonetic":"","meaning":"整句的简体中文翻译","partOfSpeech":"","examples":[],"note":""}
注意：输入中的单词可能是大写开头、带连字符或复数/时态变化，请按原形理解，不要当成拼写错误。`;

const DEFAULTS = {
  provider: 'auto',
  custom: { endpoint: '', apiKey: '', model: 'deepseek-chat', prompt: '' },
  baidu: { appid: '', key: '' },
  timeout: 9000,
  maxWords: 40,
  presets: ['解释这段话', '翻译成中文', '举一个例子', '继续展开讲讲']
};

const $ = (id) => document.getElementById(id);

function load() {
  chrome.storage.sync.get({ options: null }, (v) => {
    const o = Object.assign({}, DEFAULTS, v && v.options ? v.options : {});
    o.custom = Object.assign({}, DEFAULTS.custom, o.custom || {});
    o.baidu = Object.assign({}, DEFAULTS.baidu, o.baidu || {});
    o.presets = Array.isArray(o.presets) && o.presets.length ? o.presets : DEFAULTS.presets;

    $('provider').value = o.provider;
    $('endpoint').value = o.custom.endpoint || '';
    $('apiKey').value = o.custom.apiKey || '';
    $('model').value = o.custom.model || 'deepseek-chat';
    $('prompt').value = o.custom.prompt || '';
    $('prompt').placeholder = DEFAULT_PROMPT;
    $('baiduAppid').value = o.baidu.appid || '';
    $('baiduKey').value = o.baidu.key || '';
    $('presets').value = o.presets.join('\n');
  });
}

function save(opts) {
  const quiet = !!(opts && opts.quiet);
  const presets = $('presets')
    .value.split('\n')
    .map((s) => s.trim())
    .filter(Boolean)
    .slice(0, 8);

  const endpoint = $('endpoint').value.trim();
  const options = {
    provider: $('provider').value,
    custom: {
      endpoint,
      apiKey: $('apiKey').value.trim(),
      model: $('model').value.trim() || 'deepseek-chat',
      prompt: $('prompt').value.trim()
    },
    baidu: {
      appid: $('baiduAppid').value.trim(),
      key: $('baiduKey').value.trim()
    },
    timeout: 9000,
    maxWords: 40,
    presets: presets.length ? presets : DEFAULTS.presets
  };

  // 自定义接口不在默认放行名单里，需要用户当场授权一次该域名
  requestOrigin(endpoint)
    .then((granted) => {
      writeOptions(options, granted, quiet);
    })
    .catch(() => writeOptions(options, null, quiet));
}

function requestOrigin(endpoint) {
  if (!endpoint || !chrome.permissions || !chrome.permissions.request) return Promise.resolve(null);
  let origin;
  try {
    origin = new URL(endpoint).origin + '/*';
  } catch (_) {
    return Promise.reject(new Error('接口地址格式不正确'));
  }
  return new Promise((resolve) => {
    chrome.permissions.contains({ origins: [origin] }, (has) => {
      if (has) {
        resolve(true);
        return;
      }
      chrome.permissions.request({ origins: [origin] }, (granted) => resolve(!!granted));
    });
  });
}

function writeOptions(options, granted, quiet) {
  chrome.storage.sync.set({ options }, () => {
    if (quiet) return;
    const msg = $('msg');
    if (granted === false) {
      msg.textContent = '已保存，但没有授权访问该接口域名，翻译时可能失败';
    } else {
      msg.textContent = '已保存 ✓（到 DeepSeek 页面刷新一下即可生效）';
    }
    setTimeout(() => (msg.textContent = ''), 3800);
  });
}

function reset() {
  chrome.storage.sync.set({ options: JSON.parse(JSON.stringify(DEFAULTS)) }, () => {
    load();
    const msg = $('msg');
    msg.textContent = '已恢复默认 ✓';
    setTimeout(() => (msg.textContent = ''), 2600);
  });
}

/* --------------------- 诊断：哪些翻译源在你这里能用 --------------------- */

function probeSources() {
  const box = $('probeResult');
  box.innerHTML = '<p class="hint">正在逐个测试，请稍候…（连不上的源会等超时）</p>';

  // 先保存当前配置，让后台按最新设置去测（尤其是百度密钥和自定义接口）
  save({ quiet: true });

  let replied = false;
  try {
    chrome.runtime.sendMessage({ type: 'DSK_PROBE' }, (res) => {
      replied = true;
      const err = chrome.runtime.lastError;
      if (err) {
        box.innerHTML = '<p class="test-result test-result--bad">× 后台没响应：' + escapeHtml(err.message) + '</p>';
        return;
      }
      if (!res || !res.ok) {
        box.innerHTML = '<p class="test-result test-result--bad">× 检测失败：' + escapeHtml((res && res.error) || '未知错误') + '</p>';
        return;
      }
      renderProbe(res.rows || []);
    });
  } catch (e) {
    box.innerHTML = '<p class="test-result test-result--bad">× ' + escapeHtml(e.message) + '</p>';
    return;
  }

  setTimeout(() => {
    if (!replied) {
      box.innerHTML = '<p class="test-result test-result--busy">还在测试中…（后台可能正在等超时，再等等或重新点一次）</p>';
    }
  }, 25000);
}

function renderProbe(rows) {
  const okList = rows.filter((r) => r.status === 'ok');
  const head =
    okList.length > 0
      ? '<p class="test-result test-result--ok">✓ 可用的源：' +
        okList.map((r) => escapeHtml(r.name)).join('、') +
        '（扩展会自动优先使用它们）</p>'
      : '<p class="test-result test-result--bad">× 没有任何在线源可用。请在下面配置「自定义接口」，或填写百度翻译开放平台的密钥。</p>';

  const statusMap = {
    ok: ['<span class="probe-ok">✓ 可用</span>'],
    empty: ['<span class="probe-empty">△ 能连上但没返回</span>'],
    error: ['<span class="probe-error">× 不可用</span>']
  };

  const body = rows
    .map((r) => {
      const tags = (r.tags || []).map((t) => '<span class="probe-tag">' + escapeHtml(t) + '</span>').join('');
      const rawBlock = r.raw
        ? '<details class="probe-raw"><summary>查看原始返回（定位问题用）</summary>' +
          '<button type="button" class="probe-copy">复制这段内容</button>' +
          '<pre>' +
          escapeHtml(r.raw) +
          '</pre></details>'
        : '';
      return (
        '<tr><td>' +
        escapeHtml(r.name) +
        '<div>' +
        tags +
        '</div></td><td>' +
        statusMap[r.status][0] +
        '</td><td>' +
        escapeHtml(String(r.detail || '')) +
        rawBlock +
        '</td><td>' +
        (typeof r.ms === 'number' ? r.ms + ' ms' : '') +
        '</td></tr>'
      );
    })
    .join('');

  $('probeResult').innerHTML =
    head +
    '<table class="probe-table"><thead><tr><th>来源</th><th>结果</th><th>返回内容 / 原因</th><th>耗时</th></tr></thead><tbody>' +
    body +
    '</tbody></table>' +
    '<p class="hint">「能连上但没返回」通常是接口改了返回格式或该词查不到；「不可用」说明这个域名在你的网络下不通。</p>' +
    '<p class="hint">若要排查：点某个源下面的「查看原始返回」→「复制这段内容」，把内容发给我，我就能针对性修解析。</p>';

  // 每个「复制这段内容」按钮：复制同一个 details 里的 pre 文本
  $('probeResult')
    .querySelectorAll('.probe-copy')
    .forEach((btn) => {
      btn.addEventListener('click', () => {
        const pre = btn.parentNode && btn.parentNode.querySelector('pre');
        const text = pre ? pre.textContent : '';
        copyText(text).then(
          () => {
            btn.textContent = '已复制 ✓';
            setTimeout(() => (btn.textContent = '复制这段内容'), 1800);
          },
          () => {
            btn.textContent = '复制失败，请手动选中复制';
            setTimeout(() => (btn.textContent = '复制这段内容'), 2400);
          }
        );
      });
    });
}

function copyText(text) {
  if (navigator.clipboard && navigator.clipboard.writeText) {
    return navigator.clipboard.writeText(text);
  }
  return new Promise((resolve, reject) => {
    const ta = document.createElement('textarea');
    ta.value = text;
    document.body.appendChild(ta);
    ta.select();
    let ok = false;
    try {
      ok = document.execCommand('copy');
    } catch (_) {
      ok = false;
    }
    ta.remove();
    ok ? resolve() : reject(new Error('copy failed'));
  });
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

/* --------------------- 测试自定义接口 --------------------- */

function testEndpoint() {
  const endpoint = $('endpoint').value.trim();
  const apiKey = $('apiKey').value.trim();
  const model = $('model').value.trim() || 'deepseek-chat';
  const prompt = $('prompt').value.trim();
  const result = $('testResult');

  if (!endpoint) {
    result.className = 'test-result test-result--bad';
    result.textContent = '× 请先填写接口地址';
    return;
  }

  let origin;
  try {
    origin = new URL(endpoint).origin + '/*';
  } catch (_) {
    result.className = 'test-result test-result--bad';
    result.textContent = '× 接口地址格式不对，应形如 https://api.deepseek.com/chat/completions';
    return;
  }

  result.className = 'test-result test-result--busy';
  result.textContent = '正在申请访问 ' + origin + ' 并测试…';

  const run = (granted) => {
    if (!granted) {
      result.className = 'test-result test-result--bad';
      result.textContent = '× 没有授权访问 ' + origin + '，请重新点一次并选择「允许」';
      return;
    }
    result.textContent = '已授权，正在调用接口…';
    callOnce({ endpoint, apiKey, model, prompt })
      .then((data) => {
        result.className = 'test-result test-result--ok';
        result.textContent =
          '✓ 接口可用\n音标：' + (data.phonetic || '（未返回）') + '\n释义：' + (data.meaning || '（未返回）');
      })
      .catch((err) => {
        result.className = 'test-result test-result--bad';
        result.textContent = '× 调用失败：' + (err && err.message ? err.message : String(err));
      });
  };

  requestOrigin(endpoint).then(run, () => run(null));
}

function callOnce({ endpoint, apiKey, model, prompt }) {
  if (!chrome.permissions || !chrome.permissions.request) return Promise.reject(new Error('当前环境不支持测试'));
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 20000);
  const headers = { 'Content-Type': 'application/json' };
  if (apiKey) headers.Authorization = 'Bearer ' + apiKey;
  const body = {
    model,
    temperature: 0,
    stream: false,
    messages: [
      { role: 'system', content: prompt || DEFAULT_PROMPT },
      { role: 'user', content: '需要查询的内容：translation' }
    ]
  };
  return fetch(endpoint, { method: 'POST', headers, body: JSON.stringify(body), signal: controller.signal })
    .then((res) => {
      if (!res.ok) throw new Error('HTTP ' + res.status + (res.status === 401 ? '（API Key 不对或没生效）' : ''));
      return res.json();
    })
    .then((data) => {
      const content =
        (data && data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content) || '';
      if (!content) throw new Error('接口没有返回 choices[0].message.content，可能不是 OpenAI 兼容格式');
      const json = parseJsonLoose(content);
      if (!json) throw new Error('模型返回的不是 JSON：' + content.slice(0, 80));
      return { phonetic: json.phonetic || '', meaning: json.meaning || '' };
    })
    .catch((err) => {
      if (err && err.name === 'AbortError') throw new Error('超时（20 秒）');
      if (err && /Failed to fetch|NetworkError|load failed/i.test(err.message || '')) {
        throw new Error('网络被拦：可能是该域名无法直连，或接口不支持跨域(CORS)');
      }
      throw err;
    })
    .finally(() => clearTimeout(timer));
}

function parseJsonLoose(text) {
  const body = String(text);
  const fence = body.match(/```(?:json)?\s*([\s\S]*?)```/i);
  const inner = fence ? fence[1] : body;
  const start = inner.indexOf('{');
  const end = inner.lastIndexOf('}');
  if (start < 0 || end <= start) return null;
  try {
    return JSON.parse(inner.slice(start, end + 1));
  } catch (_) {
    return null;
  }
}

/* --------------------- 调试日志：把「请求 → 返回」原文导出来 --------------------- */

function exportLog() {
  const box = $('logBox');
  box.className = 'test-result test-result--busy';
  box.textContent = '正在读取…';
  try {
    chrome.runtime.sendMessage({ type: 'DSK_GET_LOG' }, (res) => {
      const err = chrome.runtime.lastError;
      if (err || !res || !res.ok) {
        box.className = 'test-result test-result--bad';
        box.textContent = '读取失败：' + escapeHtml((err && err.message) || (res && res.error) || '未知错误');
        return;
      }
      const text = res.text || '';
      box.className = 'test-result test-result--ok';
      box.textContent = text;
      copyText(text).then(
        () => {
          box.textContent = text + '\n\n（以上内容已复制到剪贴板，直接粘贴发给我即可）';
        },
        () => {
          box.textContent = text + '\n\n（自动复制失败，请手动全选这段文字复制）';
        }
      );
    });
  } catch (e) {
    box.className = 'test-result test-result--bad';
    box.textContent = '读取失败：' + escapeHtml(e.message);
  }
}

function clearLog() {
  try {
    chrome.runtime.sendMessage({ type: 'DSK_CLEAR_LOG' }, () => {
      const box = $('logBox');
      box.className = 'test-result test-result--busy';
      box.textContent = '日志已清空。请回 DeepSeek 页面划词点一次「英文」，再回来导出。';
    });
  } catch (_) {}
}

$('save').addEventListener('click', () => save());
$('reset').addEventListener('click', reset);
$('test').addEventListener('click', testEndpoint);
$('probe').addEventListener('click', probeSources);
$('exportLog').addEventListener('click', exportLog);
$('clearLog').addEventListener('click', clearLog);
load();
