/* 内容脚本：在网页版 DeepSeek 中监听划词，弹出「追问 / 英文」按钮组，并在原位显示小展示框。 */
(function initSidekick() {
  'use strict';

  const ASK_ENDPOINT = 'https://chat.deepseek.com/';
  const DEFAULT_PRESETS = ['解释这段话', '翻译成中文', '举一个例子', '继续展开讲讲'];

  let lastRect = null;
  let reqSeq = 0;
  let prefillTried = false;

  const SETTINGS = Object.assign({ presets: DEFAULT_PRESETS }, {});
  try {
    chrome.storage.sync.get({ options: null }, (v) => {
      const o = (v && v.options) || {};
      if (Array.isArray(o.presets) && o.presets.length) SETTINGS.presets = o.presets;
    });
  } catch (_) {}

  /* ---------------- 划词检测 ---------------- */

  function onPointerUp(e) {
    if (e.button !== 0) return;
    if (window.DSKUi.isSelectionInsideUi()) return;
    setTimeout(handleSelection, 10);
  }

  function onKeyUp(e) {
    if (e.key === 'Shift' || e.key.startsWith('Arrow') || e.key === 'a' || e.key === 'A') {
      if (window.DSKUi.isSelectionInsideUi()) return;
      setTimeout(handleSelection, 10);
    }
  }

  function handleSelection() {
    const text = window.DSKUi.getSelectionText();
    if (!text || text.length < 2 || text.length > 4000) {
      lastRect = null;
      return;
    }
    const sel = window.getSelection();
    if (!sel || sel.rangeCount === 0) return;
    const rect = sel.getRangeAt(0).getBoundingClientRect();
    if (!rect || (!rect.width && !rect.height)) return;

    const moved = !lastRect || Math.abs(lastRect.left - rect.left) > 1 || Math.abs(lastRect.top - rect.top) > 2;
    const changed = lastRect && lastRect.text !== text;
    if (!moved && !changed && window.DSKUi.hasToolbar()) return;
    lastRect = {
      text,
      left: rect.left,
      top: rect.top,
      right: rect.right,
      bottom: rect.bottom,
      width: rect.width,
      height: rect.height
    };

    window.DSKUi.showToolbar(rect, text, {
      onAsk: openAskPanel,
      onTranslate: openTranslatePanel
    });
  }

  /* ---------------- 功能一：划词追问到新对话 ---------------- */

  function buildQuestion(question, quoted) {
    return question + '\n\n> ' + quoted.replace(/\n/g, '\n> ');
  }

  function openAskPanel(text) {
    const bar = window.DSKUi.getToolbar();
    if (!bar) return;
    const { node, textarea } = window.DSKUi.buildAskPanel(text, (question) => {
      sendToNewChat(question, text);
    }, SETTINGS.presets);
    const panel = window.DSKUi.openPanel(bar, node);
    panel.__textarea = textarea;
  }

  function sendToNewChat(question, quoted) {
    const full = buildQuestion(question, quoted);
    // 直接在当前标签页开新对话（等价于点左上角「开启新对话」），不再堆一串新标签页
    const url = ASK_ENDPOINT + '?q=' + encodeURIComponent(full) + '&t=' + Date.now();
    let navigated = false;

    const go = () => {
      if (navigated) return;
      navigated = true;
      location.assign(url);
    };

    window.DSKUi.toast('正在新对话中发送…');
    window.DSKUi.closePanel();
    window.DSKUi.hideToolbar();

    // 先让后台记住「本标签页导航后要自动发送」，等它收到再跳转，避免偶发丢失
    try {
      chrome.runtime.sendMessage({ type: 'DSK_SEND_TO_NEW_CHAT', text: full }, go);
      setTimeout(go, 250);
    } catch (_) {
      go();
    }
  }

  /* ---------------- 功能二：英文读音 + 中文释义 ---------------- */

  async function openTranslatePanel(text) {
    const bar = window.DSKUi.getToolbar();
    if (!bar) return;
    if (!text || !text.trim()) {
      window.DSKUi.toast('请先选中要查询的英文内容');
      return;
    }
    const panel = window.DSKUi.openPanel(bar, window.DSKUi.buildLoadingPanel(text));
    const seq = ++reqSeq;

    let data;
    try {
      data = await window.DSKNet.requestTranslate(text);
    } catch (err) {
      if (seq !== reqSeq || !panel.isConnected) return;
      data = {
        input: text,
        phonetic: '',
        meaning: '',
        note: '查询失败：' + ((err && err.message) || '未知错误') + '（可到扩展设置里配置自己的翻译接口）',
        provider: ''
      };
    }
    if (seq !== reqSeq || !panel.isConnected) return;
    window.DSKUi.replacePanelContent(panel, window.DSKUi.buildResultPanel(data));
  }

  /* ---------------- 收到新对话页的补发请求 ---------------- */

  try {
    chrome.runtime.onMessage.addListener((msg) => {
      if (!msg || msg.type !== 'DSK_PREFILL') return;
      prefillPrompt(msg.text || '');
    });
  } catch (_) {}

  function prefillPrompt(text) {
    if (prefillTried) return;
    prefillTried = true;
    const startPath = location.pathname;
    const wanted = text.trim();
    let tries = 0;

    const timer = setInterval(() => {
      tries += 1;

      // 页面已经从「新对话」跳到具体会话，说明 DeepSeek 自己把 ?q= 发出去了
      if (location.pathname !== startPath) {
        clearInterval(timer);
        return;
      }

      const input = findChatInput();
      if (!input) {
        if (tries > 60) clearInterval(timer);
        return;
      }

      const current = readInput(input).trim();
      if (current && current !== wanted) {
        // 输入框里已经有别的内容（用户自己在打字），不要抢
        clearInterval(timer);
        return;
      }

      if (!current) writeInput(input, text);
      clearInterval(timer);
      setTimeout(() => {
        pressEnter(input);
        // 兜底：若回车没被页面接受，提示用户手动按一下
        setTimeout(() => {
          if (!input.isConnected) return;
          if (readInput(input).trim() === wanted) {
            window.DSKUi.toast('已填入追问内容，按一次 Enter 即可发送', 4200);
          }
        }, 1800);
      }, 150);
    }, 250);
  }

  function readInput(el) {
    try {
      if (el.tagName === 'TEXTAREA') return el.value || '';
      return el.textContent || '';
    } catch (_) {
      return '';
    }
  }

  function findChatInput() {
    const selectors = [
      'textarea#chat-input',
      'textarea[placeholder]',
      'div[contenteditable="true"]',
      'textarea'
    ];
    const host = document.getElementById('dsk-sidekick-root');
    for (const sel of selectors) {
      const list = document.querySelectorAll(sel);
      for (const el of list) {
        if (host && host.contains(el)) continue;
        const r = el.getBoundingClientRect();
        if (r.width > 120 && r.height > 18) return el;
      }
    }
    return null;
  }

  function writeInput(el, text) {
    try {
      el.focus();
      if (el.tagName === 'TEXTAREA') {
        const setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value').set;
        setter.call(el, text);
      } else {
        el.textContent = text;
      }
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
    } catch (_) {}
  }

  function pressEnter(el) {
    try {
      const opts = { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true };
      el.dispatchEvent(new KeyboardEvent('keydown', opts));
      el.dispatchEvent(new KeyboardEvent('keypress', opts));
      el.dispatchEvent(new KeyboardEvent('keyup', opts));
    } catch (_) {}
  }

  /* ---------------- 启动 ---------------- */

  document.addEventListener('pointerup', onPointerUp, true);
  document.addEventListener('mouseup', onPointerUp, true);
  document.addEventListener('keyup', onKeyUp, true);
  // 失焦时收起按钮组；滚动时由 ui.js 自动重新定位，不直接隐藏（避免误收起）
  window.addEventListener('blur', () => window.DSKUi.hideToolbar());

  // 告诉后台「本页内容脚本已就绪」，后台会按需把待发送的追问内容补发过来
  try {
    chrome.runtime.sendMessage({ type: 'DSK_TAB_READY' });
  } catch (_) {}

  console.info('[DeepSeek 划词助手] 已加载，选中文字试试看 ✨');
})();
